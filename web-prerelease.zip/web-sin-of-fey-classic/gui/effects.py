"""Small visual effects: floating combat text, screen shake, a scrolling log."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Tuple

import pygame

from .theme import Fonts


@dataclass
class FloatingText:
    text: str
    pos: Tuple[float, float]
    color: Tuple[int, int, int]
    age: float = 0.0
    lifetime: float = 1.1

    def update(self, dt: float) -> bool:
        self.age += dt
        return self.age < self.lifetime

    def draw(self, surface: pygame.Surface) -> None:
        t = self.age / self.lifetime
        y_offset = -40 * t
        alpha = max(0, int(255 * (1 - t)))
        img = Fonts.heading.render(self.text, True, self.color)
        img.set_alpha(alpha)
        x, y = self.pos
        surface.blit(img, img.get_rect(center=(x, y + y_offset)))


class ScreenShake:
    def __init__(self):
        self.trauma = 0.0

    def kick(self, amount: float = 0.5) -> None:
        self.trauma = min(1.0, self.trauma + amount)

    def update(self, dt: float) -> Tuple[int, int]:
        if self.trauma <= 0:
            return (0, 0)
        self.trauma = max(0.0, self.trauma - dt * 2.2)
        power = self.trauma ** 2
        import random

        return (
            int(random.uniform(-1, 1) * 14 * power),
            int(random.uniform(-1, 1) * 14 * power),
        )


@dataclass
class MessageLog:
    lines: List[Tuple[str, Tuple[int, int, int]]] = field(default_factory=list)
    max_lines: int = 400

    def add(self, text: str, color: Tuple[int, int, int]) -> None:
        for sub in text.split("\n"):
            self.lines.append((sub, color))
        self.lines = self.lines[-self.max_lines:]

    def recent(self, n: int) -> List[Tuple[str, Tuple[int, int, int]]]:
        return self.lines[-n:]
