"""The pygame application: title screen, exploration, combat, win/lose scenes."""

from __future__ import annotations

import asyncio
import sys

import pygame

from data.story import build_world
from engine.chakras import CHAKRA_ORDER
from engine.elements import Element
from engine.entities import Player

from .combat_controller import CombatController
from .effects import FloatingText, MessageLog, ScreenShake
from .theme import (
    BG_BOTTOM,
    BG_TOP,
    ELEMENT_COLORS,
    Fonts,
    GOLD,
    HP_BAD,
    HP_GOOD,
    INSIGHT_COLOR,
    PANEL_BORDER,
    SCREEN_H,
    SCREEN_W,
    TEXT_ACCENT,
    TEXT_DIM,
    TEXT_MAIN,
    vertical_gradient,
)
from .widgets import Button, draw_bar, draw_panel, draw_text_block, hp_color, layout_row, wrap_text

HUD_RECT = pygame.Rect(30, 20, SCREEN_W - 60, 66)
CHAKRA_RECT = pygame.Rect(30, 94, SCREEN_W - 60, 34)
MAIN_RECT = pygame.Rect(30, 140, SCREEN_W - 60, 300)
LOG_RECT = pygame.Rect(30, 452, SCREEN_W - 60, 168)
BUTTON_ROW = pygame.Rect(30, 634, SCREEN_W - 60, 56)

PLAYER_ANCHOR = (230, 330)
ENEMY_ANCHOR = (870, 240)

KIND_COLOR = {
    "info": TEXT_MAIN,
    "player_hit": HP_GOOD,
    "enemy_hit": HP_BAD,
    "warn": GOLD,
}


def _open_next_chakra(player: Player):
    for chakra in CHAKRA_ORDER:
        if chakra not in player.chakras.opened and len(player.artifacts) >= 1:
            if player.chakras.open_chakra(chakra):
                return chakra
            return None
    return None


class App:
    def __init__(self):
        pygame.init()
        Fonts.load()
        self.screen = pygame.display.set_mode((SCREEN_W, SCREEN_H))
        pygame.display.set_caption("The Sin of Fey")
        self.canvas = pygame.Surface((SCREEN_W, SCREEN_H))
        self.clock = pygame.time.Clock()
        self.log = MessageLog()
        self.shake = ScreenShake()
        self.floats = []
        self.world = None
        self.player = None
        self.running = True
        self.scene = TitleScene(self)

    def start_new_game(self):
        self.world = build_world()
        self.player = Player("Jesse")
        self.log = MessageLog()
        self.log.add(
            "You carry three books worth of fear: Esoteric Psychology, Phobia, "
            "and The Green Apple. Each room is a chapter. Naming a fear is how you win.",
            TEXT_DIM,
        )
        self.scene = ExploreScene(self)

    def spawn_float(self, text, pos, color):
        self.floats.append(FloatingText(text, pos, color))

    async def run(self):
        while self.running:
            dt = self.clock.tick(60) / 1000
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                else:
                    self.scene.handle_event(event)

            self.floats = [f for f in self.floats if f.update(dt)]
            self.scene.update(dt)

            self.canvas.fill((0, 0, 0))
            vertical_gradient(self.canvas, BG_TOP, BG_BOTTOM)
            self.scene.draw(self.canvas)
            for f in self.floats:
                f.draw(self.canvas)

            offset = self.shake.update(dt)
            self.screen.fill((0, 0, 0))
            self.screen.blit(self.canvas, offset)
            pygame.display.flip()
            await asyncio.sleep(0)
        pygame.quit()

    # --- shared HUD -------------------------------------------------
    def draw_hud(self, surface):
        if not self.player:
            return
        draw_panel(surface, HUD_RECT)
        p = self.player
        name_img = Fonts.heading.render(p.name, True, TEXT_MAIN)
        surface.blit(name_img, (HUD_RECT.left + 16, HUD_RECT.top + 8))

        hp_rect = pygame.Rect(HUD_RECT.left + 220, HUD_RECT.top + 12, 340, 20)
        draw_bar(surface, hp_rect, p.hp / p.max_hp, hp_color(p.hp / p.max_hp),
                 label=f"HP {p.hp}/{p.max_hp}", font=Fonts.small)

        insight_rect = pygame.Rect(HUD_RECT.left + 220, HUD_RECT.top + 38, 340, 18)
        ratio = p.chakras.insight / p.chakras.max_insight if p.chakras.max_insight else 0
        draw_bar(surface, insight_rect, ratio, INSIGHT_COLOR,
                 label=f"Insight {p.chakras.insight}/{p.chakras.max_insight}", font=Fonts.small)

        act = self.world.current_act() if self.world else None
        if act:
            book_img = Fonts.small.render(act.book, True, TEXT_ACCENT)
            surface.blit(book_img, book_img.get_rect(right=HUD_RECT.right - 16, top=HUD_RECT.top + 10))
            title_img = Fonts.small.render(act.title, True, TEXT_DIM)
            surface.blit(title_img, title_img.get_rect(right=HUD_RECT.right - 16, top=HUD_RECT.top + 32))

        draw_panel(surface, CHAKRA_RECT)
        n = len(CHAKRA_ORDER)
        gap = CHAKRA_RECT.width / n
        for i, chakra in enumerate(CHAKRA_ORDER):
            cx = int(CHAKRA_RECT.left + gap * i + gap / 2)
            cy = CHAKRA_RECT.centery
            opened = chakra in p.chakras.opened
            color = GOLD if opened else (60, 54, 74)
            pygame.draw.circle(surface, color, (cx, cy), 10)
            pygame.draw.circle(surface, PANEL_BORDER, (cx, cy), 10, width=1)
            label = Fonts.small.render(chakra.value, True, TEXT_DIM if not opened else TEXT_MAIN)
            surface.blit(label, label.get_rect(centerx=cx, top=cy + 14))

    def draw_log(self, surface):
        draw_panel(surface, LOG_RECT)
        inner = LOG_RECT.inflate(-24, -20)
        font = Fonts.small
        line_h = font.get_height() + 4
        max_lines = inner.height // line_h
        lines = self.log.recent(max_lines)
        y = inner.top
        for text, color in lines:
            for wrapped in wrap_text(text, font, inner.width):
                img = font.render(wrapped, True, color)
                surface.blit(img, (inner.left, y))
                y += line_h


class Scene:
    def __init__(self, app: App):
        self.app = app
        self.buttons = []

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for b in self.buttons:
                if b.handle_click(event.pos):
                    return
        elif event.type == pygame.KEYDOWN:
            for b in self.buttons:
                if b.handle_key(event.key):
                    return

    def update(self, dt):
        pass

    def draw(self, surface):
        raise NotImplementedError


class TitleScene(Scene):
    def __init__(self, app):
        super().__init__(app)
        btn_rect = pygame.Rect(0, 0, 360, 64)
        btn_rect.center = (SCREEN_W // 2, 520)
        self.buttons = [Button(btn_rect, "Begin the Journey", self._begin, hotkey=pygame.K_RETURN)]

    def _begin(self):
        self.app.start_new_game()

    def draw(self, surface):
        title = Fonts.title.render("THE SIN OF FEY", True, GOLD)
        surface.blit(title, title.get_rect(centerx=SCREEN_W // 2, top=120))
        subtitle = Fonts.body.render(
            "a journey through Esoteric Psychology, Phobia, and The Green Apple",
            True, TEXT_ACCENT,
        )
        surface.blit(subtitle, subtitle.get_rect(centerx=SCREEN_W // 2, top=190))

        blurb_rect = pygame.Rect(SCREEN_W // 2 - 380, 250, 760, 220)
        draw_text_block(
            surface,
            "Three books of fear wait for you, each chapter a room, each room a "
            "fear given a name. Confront your fears directly, or reflect their "
            "own nature back at them once you have opened the right chakra. "
            "Name every fear across all three books, and the Sin of Fey will "
            "dissolve into ordinary sunlight.",
            Fonts.body, TEXT_MAIN, blurb_rect,
        )
        for b in self.buttons:
            b.draw(surface, pygame.mouse.get_pos())


class ExploreScene(Scene):
    def __init__(self, app):
        super().__init__(app)
        self.player = app.player
        self.act = app.world.current_act()
        self.room = None
        self.show_inventory = False
        self.show_chakras = False
        self._enter_current_room()

    def _enter_current_room(self):
        room = self.act.current()
        while room.is_locked(self.player):
            self.app.log.add(
                f'"{room.title}" is locked, but you already hold the key it needs.',
                TEXT_DIM,
            )
            if not self.act.has_next():
                break
            room = self.act.advance()
        self.room = room
        if not room.visited:
            room.visited = True
            self.app.log.add(f"== {room.title} ==", GOLD)
            self.app.log.add(room.flavor, TEXT_MAIN)
        self._rebuild_buttons()

    def _rebuild_buttons(self):
        room = self.room
        buttons = []
        if room.phobia and room.phobia.alive and not room.cleared:
            buttons.append(Button(pygame.Rect(0, 0, 0, 0), "Confront", self._start_combat,
                                   hotkey=pygame.K_c, subtitle=f"vs {room.phobia.name}"))
        elif room.item:
            buttons.append(Button(pygame.Rect(0, 0, 0, 0), "Take Item", self._take_item,
                                   hotkey=pygame.K_t, subtitle=room.item.name))
        else:
            label = "Proceed" if not self.act.has_next() and self.act.is_complete() else "Continue"
            buttons.append(Button(pygame.Rect(0, 0, 0, 0), label, self._continue, hotkey=pygame.K_RETURN))
        buttons.append(Button(pygame.Rect(0, 0, 0, 0), "Inventory", self._toggle_inventory, hotkey=pygame.K_i))
        buttons.append(Button(pygame.Rect(0, 0, 0, 0), "Chakras", self._toggle_chakras, hotkey=pygame.K_k))
        rects = layout_row(len(buttons), BUTTON_ROW)
        for b, r in zip(buttons, rects):
            b.rect = r
        self.buttons = buttons

    def _toggle_inventory(self):
        self.show_inventory = not self.show_inventory
        self.show_chakras = False

    def _toggle_chakras(self):
        self.show_chakras = not self.show_chakras
        self.show_inventory = False

    def _start_combat(self):
        self.app.scene = CombatScene(self.app, self.room, self)

    def _take_item(self):
        item = self.room.item
        self.room.item = None
        self.player.add_item(item)
        self.app.log.add(f"You take the {item.name}. {item.description}", GOLD)
        opened = _open_next_chakra(self.player)
        if opened:
            self.app.log.add(f"A new chakra opens within you: {opened.value}.", INSIGHT_COLOR)
        self.room.cleared = True
        self._rebuild_buttons()

    def _continue(self):
        prev_book = self.act.book
        if self.act.has_next():
            self.act.advance()
            self._enter_current_room()
            return
        if self.app.world.is_final_act():
            self.app.scene = WinScene(self.app)
            return
        self.app.world.next_act()
        self.act = self.app.world.current_act()
        self.app.log.add(f"You close the book on {prev_book}. Turning the page...", TEXT_ACCENT)
        self._enter_current_room()

    def draw(self, surface):
        self.app.draw_hud(surface)
        draw_panel(surface, MAIN_RECT)
        inner = MAIN_RECT.inflate(-32, -28)

        if self.show_inventory:
            self._draw_inventory(surface, inner)
        elif self.show_chakras:
            self._draw_chakras(surface, inner)
        else:
            title_img = Fonts.heading.render(self.room.title, True, GOLD)
            surface.blit(title_img, (inner.left, inner.top))
            body_rect = pygame.Rect(inner.left, inner.top + 44, inner.width, inner.height - 44)
            draw_text_block(surface, self.room.flavor, Fonts.body, TEXT_MAIN, body_rect)
            if self.room.phobia and self.room.phobia.alive and not self.room.cleared:
                warn = Fonts.small.render(
                    f"A fear lingers here: {self.room.phobia.name} ({self.room.phobia.element})",
                    True, ELEMENT_COLORS[self.room.phobia.element],
                )
                surface.blit(warn, (inner.left, inner.bottom - 22))

        self.app.draw_log(surface)
        mouse = pygame.mouse.get_pos()
        for b in self.buttons:
            b.draw(surface, mouse)

    def _draw_inventory(self, surface, inner):
        title = Fonts.heading.render("Inventory", True, GOLD)
        surface.blit(title, (inner.left, inner.top))
        y = inner.top + 44
        if not self.player.inventory:
            empty = Fonts.body.render("Your pockets are empty.", True, TEXT_DIM)
            surface.blit(empty, (inner.left, y))
            return
        for item in self.player.inventory:
            line = f"{item.name} — {item.description}"
            for wrapped in wrap_text(line, Fonts.small, inner.width):
                img = Fonts.small.render(wrapped, True, TEXT_MAIN)
                surface.blit(img, (inner.left, y))
                y += img.get_height() + 3
            y += 6

    def _draw_chakras(self, surface, inner):
        title = Fonts.heading.render("Chakras", True, GOLD)
        surface.blit(title, (inner.left, inner.top))
        body = Fonts.body.render(self.player.chakras.progress_str(), True, TEXT_MAIN)
        surface.blit(body, (inner.left, inner.top + 50))
        hint = Fonts.small.render(
            "Opened chakras power elemental Reflect attacks in combat.", True, TEXT_DIM,
        )
        surface.blit(hint, (inner.left, inner.top + 90))


class CombatScene(Scene):
    def __init__(self, app, room, return_scene):
        super().__init__(app)
        self.room = room
        self.phobia = room.phobia
        self.player = app.player
        self.return_scene = return_scene
        self.controller = CombatController(self.player, self.phobia)
        self.pending_end = None
        self.show_items = False
        self.app.log.add(
            f'A fear takes shape: "{self.phobia.name}" ({self.phobia.element}).',
            ELEMENT_COLORS[self.phobia.element],
        )
        self.app.log.add(f'{self.phobia.name} whispers: "{self.phobia.quote}"', TEXT_DIM)
        self._rebuild_buttons()

    def _rebuild_buttons(self):
        if self.pending_end:
            btn = Button(pygame.Rect(0, 0, 0, 0), "Continue", self._resolve_end, hotkey=pygame.K_RETURN)
            rects = layout_row(1, BUTTON_ROW)
            btn.rect = rects[0]
            self.buttons = [btn]
            return

        artifact = self.player.best_reflect_element(self.phobia.element)
        can_reflect = artifact is not None and self.player.chakras.insight >= CombatController.REFLECT_COST
        healing_items = [i for i in self.player.inventory if getattr(i, "heal", 0) or getattr(i, "insight_restore", 0)]

        buttons = [
            Button(pygame.Rect(0, 0, 0, 0), "Confront", self._confront, hotkey=pygame.K_c),
            Button(pygame.Rect(0, 0, 0, 0), "Reflect", self._reflect, hotkey=pygame.K_r,
                   enabled=can_reflect, subtitle=artifact.name if artifact else "no artifact"),
            Button(pygame.Rect(0, 0, 0, 0), "Item", self._toggle_items, hotkey=pygame.K_i,
                   enabled=bool(healing_items)),
            Button(pygame.Rect(0, 0, 0, 0), "Flee", self._flee, hotkey=pygame.K_f),
        ]
        rects = layout_row(len(buttons), BUTTON_ROW)
        for b, r in zip(buttons, rects):
            b.rect = r
        self.buttons = buttons

    def _apply_outcome(self, outcome):
        for text, kind in outcome.lines:
            self.app.log.add(text, KIND_COLOR.get(kind, TEXT_MAIN))
        if outcome.player_damage_dealt:
            self.app.spawn_float(f"-{outcome.player_damage_dealt}", ENEMY_ANCHOR, HP_GOOD)
        if any(k == "enemy_hit" for _, k in outcome.lines):
            self.app.shake.kick(0.5)
            self.app.spawn_float(
                f"-{self.phobia.attack}", PLAYER_ANCHOR, HP_BAD,
            )
        if outcome.ended in ("win", "lose"):
            self.pending_end = outcome.ended
        self.show_items = False
        self._rebuild_buttons()

    def _confront(self):
        self._apply_outcome(self.controller.confront())

    def _reflect(self):
        self._apply_outcome(self.controller.reflect())

    def _toggle_items(self):
        self.show_items = not self.show_items

    def _use_item(self, item):
        self._apply_outcome(self.controller.use_item(item))

    def _flee(self):
        outcome = self.controller.flee()
        for text, kind in outcome.lines:
            self.app.log.add(text, KIND_COLOR.get(kind, TEXT_MAIN))
        self.app.scene = self.return_scene
        self.return_scene._rebuild_buttons()

    def _resolve_end(self):
        if self.pending_end == "lose":
            self.app.scene = GameOverScene(self.app)
            return
        self.room.cleared = True
        self.return_scene.room = self.room
        self.return_scene._rebuild_buttons()
        self.app.scene = self.return_scene

    def draw(self, surface):
        self.app.draw_hud(surface)
        draw_panel(surface, MAIN_RECT, glow=True)
        inner = MAIN_RECT.inflate(-32, -28)

        if self.show_items and not self.pending_end:
            self._draw_item_menu(surface, inner)
        else:
            elem_color = ELEMENT_COLORS[self.phobia.element]
            pygame.draw.circle(surface, elem_color, ENEMY_ANCHOR, 46)
            pygame.draw.circle(surface, (10, 8, 16), ENEMY_ANCHOR, 46, width=2)
            name_img = Fonts.heading.render(self.phobia.name, True, TEXT_MAIN)
            surface.blit(name_img, name_img.get_rect(centerx=ENEMY_ANCHOR[0], top=ENEMY_ANCHOR[1] + 56))
            hp_rect = pygame.Rect(ENEMY_ANCHOR[0] - 120, ENEMY_ANCHOR[1] + 90, 240, 18)
            draw_bar(surface, hp_rect, self.phobia.hp / self.phobia.max_hp, hp_color(self.phobia.hp / self.phobia.max_hp),
                     label=f"{self.phobia.hp}/{self.phobia.max_hp}", font=Fonts.small)

            pygame.draw.circle(surface, (90, 70, 120), PLAYER_ANCHOR, 40)
            pygame.draw.circle(surface, (10, 8, 16), PLAYER_ANCHOR, 40, width=2)
            you_img = Fonts.body.render("You", True, TEXT_MAIN)
            surface.blit(you_img, you_img.get_rect(centerx=PLAYER_ANCHOR[0], top=PLAYER_ANCHOR[1] + 50))

            quote_rect = pygame.Rect(inner.left, inner.top, inner.width, 40)
            draw_text_block(surface, f'"{self.phobia.quote}"', Fonts.small, TEXT_DIM, quote_rect)

            if self.pending_end == "win":
                msg = Fonts.heading.render("The fear dissolves.", True, GOLD)
                surface.blit(msg, msg.get_rect(centerx=MAIN_RECT.centerx, top=inner.bottom - 34))
            elif self.pending_end == "lose":
                msg = Fonts.heading.render("You are overwhelmed...", True, HP_BAD)
                surface.blit(msg, msg.get_rect(centerx=MAIN_RECT.centerx, top=inner.bottom - 34))

        self.app.draw_log(surface)
        mouse = pygame.mouse.get_pos()
        for b in self.buttons:
            b.draw(surface, mouse)

    def _draw_item_menu(self, surface, inner):
        title = Fonts.heading.render("Use which item?", True, GOLD)
        surface.blit(title, (inner.left, inner.top))
        items = [i for i in self.player.inventory if getattr(i, "heal", 0) or getattr(i, "insight_restore", 0)]
        rects = layout_row(max(len(items), 1), pygame.Rect(inner.left, inner.top + 60, inner.width, 60))
        item_buttons = []
        for item, rect in zip(items, rects):
            btn = Button(rect, item.name, (lambda it=item: self._use_item(it)), subtitle=item.description[:28])
            item_buttons.append(btn)
        for b in item_buttons:
            b.draw(surface, pygame.mouse.get_pos())
        self._item_buttons = item_buttons

    def handle_event(self, event):
        if self.show_items and not self.pending_end:
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                for b in getattr(self, "_item_buttons", []):
                    if b.handle_click(event.pos):
                        return
                self.show_items = False
                return
        super().handle_event(event)


class GameOverScene(Scene):
    def __init__(self, app):
        super().__init__(app)
        rect = pygame.Rect(0, 0, 300, 60)
        rect.center = (SCREEN_W // 2, 460)
        self.buttons = [Button(rect, "Try Again", app.start_new_game, hotkey=pygame.K_RETURN)]

    def draw(self, surface):
        title = Fonts.title.render("YOUR FEARS OVERWHELM YOU", True, HP_BAD)
        surface.blit(title, title.get_rect(centerx=SCREEN_W // 2, top=220))
        sub = Fonts.body.render("THE END", True, TEXT_DIM)
        surface.blit(sub, sub.get_rect(centerx=SCREEN_W // 2, top=300))
        for b in self.buttons:
            b.draw(surface, pygame.mouse.get_pos())


class WinScene(Scene):
    def __init__(self, app):
        super().__init__(app)
        rect = pygame.Rect(0, 0, 300, 60)
        rect.center = (SCREEN_W // 2, 480)
        self.buttons = [Button(rect, "Play Again", app.start_new_game, hotkey=pygame.K_RETURN)]

    def draw(self, surface):
        title = Fonts.title.render("THE SIN OF FEY DISSOLVES", True, GOLD)
        surface.blit(title, title.get_rect(centerx=SCREEN_W // 2, top=200))
        blurb_rect = pygame.Rect(SCREEN_W // 2 - 380, 270, 760, 140)
        draw_text_block(
            surface,
            "You have named every fear across all three books: Esoteric "
            "Psychology, Phobia, and The Green Apple. The garden is only a "
            "garden now, and the apple is only an apple.",
            Fonts.body, TEXT_MAIN, blurb_rect,
        )
        for b in self.buttons:
            b.draw(surface, pygame.mouse.get_pos())


async def main():
    await App().run()
    return 0
