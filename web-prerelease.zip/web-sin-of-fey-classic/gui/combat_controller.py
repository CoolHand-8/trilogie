"""A non-blocking combat controller: one discrete action per call, for the
pygame event loop (as opposed to engine.combat.Combat, which blocks on input())."""

from dataclasses import dataclass
from typing import List, Optional, Tuple

from engine.entities import Phobia, Player


def _the(name: str) -> str:
    return name if name.lower().startswith("the ") else f"the {name}"


@dataclass
class ActionOutcome:
    lines: List[Tuple[str, str]]  # (text, kind) kind in {"info","player_hit","enemy_hit","warn"}
    player_damage_dealt: int = 0
    enemy_damage_dealt: int = 0
    ended: Optional[str] = None  # "win" | "lose" | None


class CombatController:
    REFLECT_COST = 6

    def __init__(self, player: Player, phobia: Phobia):
        self.player = player
        self.phobia = phobia
        self.turn_over = False

    def _enemy_turn(self, lines: List[Tuple[str, str]]) -> Optional[str]:
        if not self.phobia.alive:
            return "win"
        dmg = self.phobia.strike()
        self.player.take_damage(dmg)
        lines.append((f"{self.phobia.name} strikes back for {dmg} damage.", "enemy_hit"))
        if not self.player.alive:
            lines.append((f"{_the(self.phobia.name).capitalize()} overwhelms you...", "warn"))
            return "lose"
        return None

    def confront(self) -> ActionOutcome:
        lines: List[Tuple[str, str]] = []
        dmg = self.player.confront()
        self.phobia.take_damage(dmg)
        lines.append((f"You confront {_the(self.phobia.name)} directly for {dmg} damage.", "player_hit"))
        if not self.phobia.alive:
            lines.append((f"{_the(self.phobia.name).capitalize()} dissolves. You have named it, and it fades.", "info"))
            return ActionOutcome(lines, player_damage_dealt=dmg, ended="win")
        ended = self._enemy_turn(lines)
        return ActionOutcome(lines, player_damage_dealt=dmg, enemy_damage_dealt=0 if ended else 0, ended=ended)

    def reflect(self) -> ActionOutcome:
        lines: List[Tuple[str, str]] = []
        artifact = self.player.best_reflect_element(self.phobia.element)
        if not artifact:
            lines.append(("You have no artifact tuned to a chakra yet.", "warn"))
            return ActionOutcome(lines)
        if not self.player.chakras.spend(self.REFLECT_COST):
            lines.append(("Your chakras are too drained (not enough Insight).", "warn"))
            return ActionOutcome(lines)
        dmg = self.player.reflect(artifact, self.phobia.element)
        self.phobia.take_damage(dmg)
        lines.append((
            f"You reflect {_the(self.phobia.name)}'s fear with the {artifact.name} "
            f"({artifact.element}) for {dmg} damage.",
            "player_hit",
        ))
        if not self.phobia.alive:
            lines.append((f"{_the(self.phobia.name).capitalize()} dissolves. You have named it, and it fades.", "info"))
            return ActionOutcome(lines, player_damage_dealt=dmg, ended="win")
        ended = self._enemy_turn(lines)
        return ActionOutcome(lines, player_damage_dealt=dmg, ended=ended)

    def use_item(self, item) -> ActionOutcome:
        lines: List[Tuple[str, str]] = []
        heal = getattr(item, "heal", 0)
        insight = getattr(item, "insight_restore", 0)
        if not heal and not insight:
            lines.append(("Nothing happens.", "warn"))
            return ActionOutcome(lines)
        self.player.hp = min(self.player.max_hp, self.player.hp + heal)
        self.player.chakras.restore(insight)
        lines.append((item.use_message(), "info"))
        self.player.inventory.remove(item)
        if item in self.player.artifacts:
            self.player.artifacts.remove(item)
        ended = self._enemy_turn(lines)
        return ActionOutcome(lines, ended=ended)

    def flee(self) -> ActionOutcome:
        lines = [("You retreat, shaken, to gather your thoughts.", "info")]
        self.player.rest()
        lines.append(("You rest and gather yourself. (HP and Insight partially restored.)", "info"))
        return ActionOutcome(lines, ended="fled")
