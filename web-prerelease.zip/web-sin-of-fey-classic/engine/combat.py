"""Turn-based combat between the Player and a Phobia."""

from .entities import Phobia, Player


def _the(name: str) -> str:
    """Prefix with 'the' unless the name already starts with an article."""
    return name if name.lower().startswith("the ") else f"the {name}"


class CombatResult:
    WIN = "win"
    LOSE = "lose"
    FLED = "fled"


class Combat:
    def __init__(self, player: Player, phobia: Phobia, io):
        self.player = player
        self.phobia = phobia
        self.io = io  # object with .say(str) and .ask(prompt) -> str

    def run(self) -> str:
        io = self.io
        io.say(f'\nA fear takes shape: "{self.phobia.name}" ({self.phobia.element}).')
        io.say(f'  {self.phobia.name} whispers: "{self.phobia.quote}"')

        while self.player.alive and self.phobia.alive:
            io.say(
                f"\nYou: {self.player.hp}/{self.player.max_hp} HP | "
                f"Insight: {self.player.chakras.insight}/{self.player.chakras.max_insight}   "
                f"{self.phobia.name}: {self.phobia.hp}/{self.phobia.max_hp} HP"
            )
            action = io.ask(
                "Choose: [c]onfront, [r]eflect, [i]tem, [f]lee > "
            ).strip().lower()

            if action in ("c", "confront"):
                dmg = self.player.confront()
                self.phobia.take_damage(dmg)
                io.say(f"You confront {_the(self.phobia.name)} directly for {dmg} damage.")
            elif action in ("r", "reflect"):
                artifact = self.player.best_reflect_element(self.phobia.element)
                if not artifact:
                    io.say("You have no artifact tuned to a chakra yet.")
                    continue
                cost = 6
                if not self.player.chakras.spend(cost):
                    io.say("Your chakras are too drained (not enough Insight).")
                    continue
                dmg = self.player.reflect(artifact, self.phobia.element)
                self.phobia.take_damage(dmg)
                io.say(
                    f"You reflect {_the(self.phobia.name)}'s fear with the "
                    f"{artifact.name} ({artifact.element}) for {dmg} damage."
                )
            elif action in ("i", "item"):
                self._use_item()
                continue
            elif action in ("f", "flee"):
                io.say("You retreat, shaken, to gather your thoughts.")
                return CombatResult.FLED
            else:
                io.say("The fear presses in while you hesitate.")

            if not self.phobia.alive:
                break

            dmg = self.phobia.strike()
            self.player.take_damage(dmg)
            io.say(f"{self.phobia.name} strikes back for {dmg} damage.")

        if self.player.alive:
            io.say(f"\n{_the(self.phobia.name).capitalize()} dissolves. You have named it, and it fades.")
            return CombatResult.WIN
        io.say(f"\n{_the(self.phobia.name).capitalize()} overwhelms you...")
        return CombatResult.LOSE

    def _use_item(self):
        io = self.io
        healing = [i for i in self.player.inventory if getattr(i, "heal", 0) or getattr(i, "insight_restore", 0)]
        if not healing:
            io.say("You have no usable healing items.")
            return
        io.say("Items: " + ", ".join(f"{i}" for i in healing))
        choice = io.ask("Use which item? (name, or blank to cancel) > ").strip()
        for i in healing:
            if i.name.lower() == choice.lower():
                self.player.hp = min(self.player.max_hp, self.player.hp + getattr(i, "heal", 0))
                self.player.chakras.restore(getattr(i, "insight_restore", 0))
                io.say(i.use_message())
                self.player.inventory.remove(i)
                if i in self.player.artifacts:
                    self.player.artifacts.remove(i)
                return
        io.say("Nothing happens.")
