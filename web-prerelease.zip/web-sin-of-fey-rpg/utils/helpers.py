"""Small utility helpers: dice rolls and command parsing."""

import random
from typing import Tuple


def roll(sides: int = 6, times: int = 1) -> int:
    return sum(random.randint(1, sides) for _ in range(times))


def parse_command(raw: str) -> Tuple[str, str]:
    """Splits "move north" into ("move", "north")."""
    parts = raw.strip().split(maxsplit=1)
    if not parts:
        return "", ""
    cmd = parts[0].lower()
    arg = parts[1] if len(parts) > 1 else ""
    return cmd, arg
