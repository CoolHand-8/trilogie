"""Builds the explorable world: three connected regions echoing the trilogy's
three books (Esoteric Psychology, Phobia, The Green Apple), with enemies,
NPCs, dialogue, and loot linking them together."""

from entities.item import Armor, Consumable, KeyItem, Weapon
from entities.npc import Enemy, NPC
from mechanics.dialogue import DialogueNode, DialogueTree
from world.location import Location
from world.map import WorldMap


def _build_dialogues():
    return {
        "archivist": DialogueTree(
            start="root",
            nodes={
                "root": DialogueNode(
                    "The Archivist looks up from a ledger of names. "
                    '"Every fear in here was written down by someone who survived it. What do you want to know?"',
                    responses=[
                        ("Why write them down at all?", "why_write"),
                        ("Nothing. Just passing through.", None),
                    ],
                ),
                "why_write": DialogueNode(
                    '"A name on a page stops circling in your chest. It is proof you survived it long enough to describe it."',
                    responses=[("Thank you.", None)],
                ),
            },
        ),
        "tired_nurse": DialogueTree(
            start="root",
            nodes={
                "root": DialogueNode(
                    'A tired nurse rubs her eyes. "The Hypnotist keeps telling patients to sleep. Half of them stop trusting their own eyelids."',
                    responses=[
                        ("How do you help them?", "help"),
                        ("Good luck.", None),
                    ],
                ),
                "help": DialogueNode(
                    '"I remind them what is verifiable: the floor, their breath, their own name. No voice owns your attention without permission."',
                    responses=[("That helps. Thank you.", None)],
                ),
            },
        ),
        "gardener": DialogueTree(
            start="root",
            nodes={
                "root": DialogueNode(
                    'A quiet gardener prunes a red apple tree. "Wanting is not wrongdoing. People forget that here."',
                    responses=[
                        ("What about the green apple?", "green_apple"),
                        ("I should keep moving.", None),
                    ],
                ),
                "green_apple": DialogueNode(
                    '"There is no purity trial waiting at the center of the garden. You are allowed to be seen, to choose, and to remain whole."',
                    responses=[("I understand.", None)],
                ),
            },
        ),
    }


def build_world() -> WorldMap:
    locations = {
        "archive_entrance": Location(
            key="archive_entrance",
            name="Archive Entrance",
            description="A cold study lined with journals, the smell of old paper and older grief.",
            exits={"north": "archive_hall"},
            items=[Consumable("Stale Coffee", "Bitter, but it clears the head. Heals a little.", heal=8)],
        ),
        "archive_hall": Location(
            key="archive_hall",
            name="The Archive Hall",
            description="Shelves of case files stretch further than the ceiling should allow.",
            exits={"south": "archive_entrance", "north": "sinister_study", "east": "throat_gallery"},
        ),
        "sinister_study": Location(
            key="sinister_study",
            name="Sinister's Study",
            description="Something sits in the dark corner, calling itself Sinister.",
            exits={"south": "archive_hall"},
            enemies=[Enemy(
                "Sinister", max_hp=30, attack=6, defense=1, xp_reward=20,
                loot=[KeyItem("Rusted Key", "A small key that smells of a locked threshold.")],
                quote="You wrote me down, but you never looked at me.",
            )],
        ),
        "throat_gallery": Location(
            key="throat_gallery",
            name="The Throat Gallery",
            description="Portraits line the hall, every mouth painted slightly open.",
            exits={"west": "archive_hall", "north": "temple_threshold"},
            npcs=[NPC("The Archivist", dialogue_key="archivist")],
        ),
        "temple_threshold": Location(
            key="temple_threshold",
            name="The Temple Threshold",
            description="A sealed door built from ribs and mucus membrane, humming softly.",
            exits={"south": "throat_gallery", "north": "clinic_gate"},
            requires_key="Rusted Key",
        ),
        "clinic_gate": Location(
            key="clinic_gate",
            name="Phobia Clinic — Gate",
            description="A waiting room where every chair faces a different door.",
            exits={"south": "temple_threshold", "north": "insomnia_ward"},
            items=[Consumable("Quinine Vial", "Bitter medicine turned charm. Heals and clears the mind.", heal=14, insight_restore=6)],
        ),
        "insomnia_ward": Location(
            key="insomnia_ward",
            name="The Insomnia Ward",
            description="A bedroom where the clock hands spin but the light never changes.",
            exits={"south": "clinic_gate", "north": "hypnotist_office"},
            enemies=[Enemy(
                "Insomnia", max_hp=34, attack=7, defense=1, xp_reward=24,
                loot=[KeyItem("Brass Latch", "A latch pried from a door that would not stay shut.")],
                quote="Close your eyes. I'll still be counting.",
            )],
        ),
        "hypnotist_office": Location(
            key="hypnotist_office",
            name="The Hypnotist's Office",
            description="A voice keeps saying 'Sleep' from somewhere behind your own eyes.",
            exits={"south": "insomnia_ward", "east": "diamond_vault"},
            npcs=[NPC("A Tired Nurse", dialogue_key="tired_nurse")],
            enemies=[Enemy(
                "The Hypnotist", max_hp=38, attack=8, defense=2, xp_reward=28,
                loot=[Weapon("Cracked Pocketwatch", "Stopped at the moment you stopped listening.", attack_bonus=4)],
                quote='He usually only says, "Don\'t!" But I do.',
            )],
        ),
        "diamond_vault": Location(
            key="diamond_vault",
            name="The Diamond Vault",
            description="A crystalline chamber, every facet a different fear crystallized.",
            exits={"west": "hypnotist_office", "north": "orchard_gate"},
            enemies=[Enemy(
                "The Diamond of the Mind", max_hp=55, attack=10, defense=3, xp_reward=45,
                loot=[Armor("Faceted Ward", "Precision turned outward as protection.", defense_bonus=4)],
                quote="Cut clean enough, and even fear becomes beautiful.",
            )],
        ),
        "orchard_gate": Location(
            key="orchard_gate",
            name="Orchard Gate",
            description="An iron gate rusted shut, red apples visible through the bars.",
            exits={"south": "diamond_vault", "north": "orchard_row"},
            requires_key="Brass Latch",
        ),
        "orchard_row": Location(
            key="orchard_row",
            name="The Red Apple Row",
            description="An orchard row of red apples, each one a small, ordinary temptation.",
            exits={"south": "orchard_gate", "north": "garden_heart"},
            npcs=[NPC("A Quiet Gardener", dialogue_key="gardener")],
            enemies=[Enemy(
                "Red Apple", max_hp=42, attack=9, defense=2, xp_reward=36,
                loot=[Consumable("Seed of the Red Apple", "Bitten and understood rather than feared.", heal=20)],
                quote="I am only what you were always allowed to want.",
            )],
        ),
        "garden_heart": Location(
            key="garden_heart",
            name="The Garden's Heart",
            description="The green apple hangs untouched. The serpent waits not to tempt you, but to be understood.",
            exits={"south": "orchard_row"},
            enemies=[Enemy(
                "The Sin of Fey", max_hp=80, attack=12, defense=4, xp_reward=100,
                quote="I am not the sin. I am only the sight of yourself, unguarded.",
            )],
        ),
    }

    return WorldMap(locations=locations, start="archive_entrance", dialogues=_build_dialogues())
