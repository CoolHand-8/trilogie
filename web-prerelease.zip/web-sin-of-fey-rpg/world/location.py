"""A single explorable place in the world: description, exits, and inhabitants."""

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from entities.item import Item
from entities.npc import Enemy, NPC


@dataclass
class Location:
    key: str
    name: str
    description: str
    exits: Dict[str, str] = field(default_factory=dict)
    npcs: List[NPC] = field(default_factory=list)
    enemies: List[Enemy] = field(default_factory=list)
    items: List[Item] = field(default_factory=list)
    requires_key: Optional[str] = None
    visited: bool = False

    def is_locked(self, player) -> bool:
        if not self.requires_key:
            return False
        return not player.inventory.has(self.requires_key)

    def has_living_enemies(self) -> bool:
        return any(e.alive for e in self.enemies)
