"""The world graph: named Locations connected by exits, plus their dialogues."""

from typing import Dict, Optional

from mechanics.dialogue import DialogueTree
from world.location import Location


class WorldMap:
    def __init__(self, locations: Dict[str, Location], start: str, dialogues: Optional[Dict[str, DialogueTree]] = None):
        self.locations = locations
        self.current_key = start
        self.dialogues = dialogues or {}

    @property
    def current(self) -> Location:
        return self.locations[self.current_key]

    def move(self, direction: str) -> Optional[Location]:
        destination_key = self.current.exits.get(direction)
        if destination_key is None:
            return None
        self.current_key = destination_key
        return self.current
