"""Global constants and configuration for the RPG."""

GAME_TITLE = "The Sin of Fey — RPG"

STARTING_HP = 40
STARTING_ATTACK = 6
STARTING_DEFENSE = 1
STARTING_GOLD = 10
STARTING_INSIGHT = 20

# Reserved for a future graphical (pygame) front end.
SCREEN_W, SCREEN_H = 1100, 720


def xp_for_level(level: int) -> int:
    """Total XP required to reach `level` (level 1 requires 0)."""
    return max(0, (level - 1) * 40 + (level - 1) ** 2 * 10)
