# Deploying this web build

The playable browser build lives in `build/web/`:

- `index.html` — the page to open/host
- `web-sin-of-fey-rpg.apk` — the packaged Python/game code (a zip, loaded by index.html)
- `favicon.png`

## Host it
Upload the **contents of `build/web/`** to any static web host (itch.io "HTML5" upload,
GitHub Pages, Netlify, S3, etc.) and open `index.html`. No server-side code is needed;
it must be served over http(s), not opened as a local `file://` path.

## About this version
This is the free-roaming text RPG (`a & b & rpg/rpg`). Since browsers can't block on
real console `input()`, `main.py` wraps the same game logic in a small pygame text
console (scrolling log + on-screen input box) driven by `asyncio`.

## Rebuild after editing the source
```
python -m pip install pygbag
python -m pygbag --build --archive .
```

This regenerates `build/web/`.
