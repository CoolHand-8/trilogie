"""Simple branching dialogue trees for NPC conversations."""

from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Tuple


@dataclass
class DialogueNode:
    text: str
    responses: List[Tuple[str, Optional[str]]] = field(default_factory=list)
    on_enter: Optional[Callable[[], None]] = None


class DialogueTree:
    def __init__(self, nodes: Dict[str, DialogueNode], start: str):
        self.nodes = nodes
        self.start = start

    async def run(self, io) -> None:
        key = self.start
        while key is not None:
            node = self.nodes[key]
            if node.on_enter:
                node.on_enter()
            io.say(f"\n{node.text}")
            if not node.responses:
                return
            for index, (label, _) in enumerate(node.responses, start=1):
                io.say(f"  {index}. {label}")
            choice = (await io.ask("> ")).strip()
            try:
                idx = int(choice) - 1
                if idx < 0:
                    raise IndexError
                _, next_key = node.responses[idx]
            except (ValueError, IndexError):
                io.say("...")
                continue
            key = next_key
