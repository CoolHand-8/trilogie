"""Inventory and equipment management."""

from typing import List, Optional

from entities.item import Armor, Consumable, Item, Weapon


class Inventory:
    def __init__(self):
        self.items: List[Item] = []

    def add(self, item: Item) -> None:
        self.items.append(item)

    def remove(self, item: Item) -> None:
        if item in self.items:
            self.items.remove(item)

    def has(self, name: str) -> bool:
        return any(i.name.lower() == name.lower() for i in self.items)

    def find(self, name: str) -> Optional[Item]:
        name = name.lower()
        for item in self.items:
            if item.name.lower() == name:
                return item
        return None

    def consumables(self) -> List[Consumable]:
        return [i for i in self.items if isinstance(i, Consumable)]

    def equippable(self) -> List[Item]:
        return [i for i in self.items if isinstance(i, (Weapon, Armor))]

    def use(self, item: Consumable, player) -> str:
        player.heal(item.heal)
        player.restore_insight(item.insight_restore)
        self.remove(item)
        return item.use_message()
