"""Turn-based combat between the player and an enemy."""


class CombatResult:
    WIN = "win"
    LOSE = "lose"
    FLED = "fled"


class Combat:
    def __init__(self, player, enemy, io):
        self.player = player
        self.enemy = enemy
        self.io = io  # object with .say(str) and .ask(prompt) -> str

    async def run(self) -> str:
        io = self.io
        io.say(f"\n{self.enemy.name} blocks your path.")
        if self.enemy.quote:
            io.say(f'  "{self.enemy.quote}"')

        while self.player.alive and self.enemy.alive:
            io.say(
                f"\nYou: {self.player.hp}/{self.player.max_hp} HP | "
                f"{self.enemy.name}: {self.enemy.hp}/{self.enemy.max_hp} HP"
            )
            action = (await io.ask("Choose: [a]ttack, [i]tem, [f]lee > ")).strip().lower()

            if action in ("a", "attack"):
                dmg = self.enemy.take_damage(self.player.total_attack)
                io.say(f"You strike {self.enemy.name} for {dmg} damage.")
            elif action in ("i", "item"):
                if not await self._use_item():
                    continue
            elif action in ("f", "flee"):
                # Fleeing always carries a risk: the enemy gets a parting hit.
                mitigated = self.player.take_damage(self.enemy.attack)
                io.say(f"You break away, but {self.enemy.name} lands a parting blow for {mitigated} damage.")
                if not self.player.alive:
                    io.say(f"{self.enemy.name} overwhelms you...")
                    return CombatResult.LOSE
                return CombatResult.FLED
            else:
                io.say("The enemy presses in while you hesitate.")

            if not self.enemy.alive:
                break

            dmg = self.player.take_damage(self.enemy.strike())
            io.say(f"{self.enemy.name} strikes back for {dmg} damage.")

        if self.player.alive:
            io.say(f"\n{self.enemy.name} is defeated!")
            return CombatResult.WIN
        io.say(f"\n{self.enemy.name} overwhelms you...")
        return CombatResult.LOSE

    async def _use_item(self) -> bool:
        io = self.io
        consumables = self.player.inventory.consumables()
        if not consumables:
            io.say("You have no usable items.")
            return False
        io.say("Items: " + ", ".join(str(i) for i in consumables))
        choice = (await io.ask("Use which item? (name, or blank to cancel) > ")).strip()
        item = self.player.inventory.find(choice)
        if item and item in consumables:
            io.say(self.player.inventory.use(item, self.player))
            return True
        io.say("Nothing happens.")
        return False
