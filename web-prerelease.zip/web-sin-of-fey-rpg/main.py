#!/usr/bin/env python3
"""The Sin of Fey — RPG: web (browser) build, built for pygbag.

The original game is a blocking-input CLI. This entry point wraps the same
game logic in a small pygame text console (scrolling log + input box) driven
by asyncio, since browsers cannot block on real stdin.
"""

import asyncio

import pygame

from core.settings import GAME_TITLE
from entities.player import Player
from mechanics.combat import Combat, CombatResult
from utils.helpers import parse_command
from world.story_data import build_world

SCREEN_W, SCREEN_H = 1000, 680
BG_COLOR = (18, 14, 26)
TEXT_COLOR = (230, 224, 240)
DIM_COLOR = (150, 140, 168)
ACCENT_COLOR = (255, 208, 92)
INPUT_BG = (34, 28, 46)
INPUT_BORDER = (90, 78, 116)

DIRECTION_ALIASES = {"n": "north", "s": "south", "e": "east", "w": "west"}


def _wrap(text, font, max_width):
    lines = []
    for raw_line in str(text).split("\n"):
        words = raw_line.split(" ")
        current = ""
        for word in words:
            trial = f"{current} {word}".strip()
            if font.size(trial)[0] <= max_width or not current:
                current = trial
            else:
                lines.append(current)
                current = word
        lines.append(current)
    return lines


class PygameIO:
    """A .say()/.ask() console backed by an on-screen log and input box."""

    def __init__(self):
        self.entries = []  # (text, color)
        self.input_queue: asyncio.Queue[str] = asyncio.Queue()
        self.current_input = ""

    def say(self, text: str = "") -> None:
        for raw_line in str(text).split("\n"):
            self.entries.append((raw_line, TEXT_COLOR))

    async def ask(self, prompt: str) -> str:
        prompt = prompt.strip()
        if prompt:
            self.entries.append((prompt, ACCENT_COLOR))
        text = await self.input_queue.get()
        self.entries.append((f"> {text}", DIM_COLOR))
        return text

    def feed_text(self, text: str) -> None:
        self.current_input += text

    def backspace(self) -> None:
        self.current_input = self.current_input[:-1]

    def submit(self) -> None:
        text = self.current_input
        self.current_input = ""
        self.input_queue.put_nowait(text)


class Game:
    def __init__(self, io: PygameIO):
        self.io = io
        self.world = build_world()
        self.player = Player(name="Wanderer")
        self.running = True

    def intro(self) -> None:
        io = self.io
        io.say("=" * 60)
        io.say(f"        {GAME_TITLE}")
        io.say("=" * 60)
        io.say(
            "\nExplore the three regions of the trilogy freely. Fight the fears "
            "that block your path, talk to those who remember them, and carry "
            "what you find between rooms.\n"
        )
        io.say("Commands: look, move <direction>, take [name], talk <name>, fight,")
        io.say("          inventory, equip <name>, use <name>, stats, quit\n")

    async def run(self) -> None:
        self.intro()
        while self.running and self.player.alive:
            self._describe_location()
            await self._prompt()
        if not self.player.alive:
            self.io.say("\nYour fears have overwhelmed you. THE END.")

    def _describe_location(self) -> None:
        loc = self.world.current
        if not loc.visited:
            loc.visited = True
            self.io.say(f"\n== {loc.name} ==")
            self.io.say(loc.description)
        if loc.has_living_enemies():
            names = ", ".join(e.name for e in loc.enemies if e.alive)
            self.io.say(f"A fear lingers here: {names}.")

    async def _prompt(self) -> None:
        cmd, arg = parse_command(await self.io.ask("\n> "))

        if cmd in ("quit", "exit"):
            self.running = False
        elif cmd == "look":
            self.io.say(self.world.current.description)
            self._list_exits()
        elif cmd in ("move", "go", "n", "s", "e", "w", "north", "south", "east", "west"):
            direction = arg or DIRECTION_ALIASES.get(cmd, cmd)
            self._move(direction)
        elif cmd == "take":
            self._take(arg)
        elif cmd == "talk":
            await self._talk(arg)
        elif cmd == "fight":
            await self._fight()
        elif cmd in ("inventory", "inv", "i"):
            self._show_inventory()
        elif cmd == "equip":
            self._equip(arg)
        elif cmd == "use":
            self._use(arg)
        elif cmd == "stats":
            self._show_stats()
        else:
            self.io.say(
                "Unknown command. Try: look, move <direction>, take, talk <name>, "
                "fight, inventory, equip <name>, use <name>, stats, quit"
            )

    def _list_exits(self) -> None:
        exits = ", ".join(self.world.current.exits.keys())
        self.io.say(f"Exits: {exits or 'none'}")

    def _move(self, direction: str) -> None:
        loc = self.world.current
        if loc.has_living_enemies():
            self.io.say("You cannot leave while a fear still blocks your path. Try: fight")
            return
        destination_key = loc.exits.get(direction)
        if not destination_key:
            self.io.say(f"There is no way {direction or 'there'} from here.")
            return
        destination = self.world.locations[destination_key]
        if destination.is_locked(self.player):
            self.io.say(f'"{destination.name}" is sealed. It needs: {destination.requires_key}.')
            return
        self.world.move(direction)
        # The room's arrival description is printed by the main loop's next
        # call to _describe_location(); calling it here too would duplicate
        # the "a fear lingers here" line.

    def _take(self, name: str) -> None:
        loc = self.world.current
        if not loc.items:
            self.io.say("There is nothing here to take.")
            return
        item = next((i for i in loc.items if not name or i.name.lower() == name.lower()), None)
        if not item:
            self.io.say(f"There is no {name} here.")
            return
        loc.items.remove(item)
        self.player.inventory.add(item)
        self.io.say(f"You take the {item.name}. {item.description}")

    async def _talk(self, name: str) -> None:
        loc = self.world.current
        npc = next((n for n in loc.npcs if name.lower() in n.name.lower()), None)
        if not npc:
            self.io.say("There is no one here by that name.")
            return
        await self.world.dialogues[npc.dialogue_key].run(self.io)

    async def _fight(self) -> None:
        loc = self.world.current
        enemy = next((e for e in loc.enemies if e.alive), None)
        if not enemy:
            self.io.say("Nothing here to fight.")
            return
        result = await Combat(self.player, enemy, self.io).run()
        if result == CombatResult.WIN:
            for message in self.player.gain_xp(enemy.xp_reward):
                self.io.say(message)
            for item in enemy.loot:
                self.player.inventory.add(item)
                self.io.say(f"You recover the {item.name} from the fear that named it.")
            if loc.key == "garden_heart" and not loc.has_living_enemies():
                self.io.say(
                    "\nThe Sin of Fey dissolves into ordinary sunlight. You have named "
                    "every fear that mattered. THE END."
                )
                self.running = False
        elif result == CombatResult.FLED:
            self.io.say("You retreat, shaken.")

    def _show_inventory(self) -> None:
        if not self.player.inventory.items:
            self.io.say("Your pockets are empty.")
            return
        for item in self.player.inventory.items:
            self.io.say(f" - {item}: {item.description}")

    def _equip(self, name: str) -> None:
        item = self.player.inventory.find(name)
        if not item:
            self.io.say(f"You have no {name} to equip.")
            return
        self.io.say(self.player.equip(item))

    def _use(self, name: str) -> None:
        item = self.player.inventory.find(name)
        if not item or item not in self.player.inventory.consumables():
            self.io.say(f"You have no usable {name}.")
            return
        self.io.say(self.player.inventory.use(item, self.player))

    def _show_stats(self) -> None:
        p = self.player
        self.io.say(
            f"\n{p.name} — Level {p.level}\n"
            f"HP: {p.hp}/{p.max_hp}  Attack: {p.total_attack}  Defense: {p.total_defense}\n"
            f"Insight: {p.insight}/{p.max_insight}  XP: {p.xp}  Gold: {p.gold}"
        )


def _draw(screen, font, io: PygameIO):
    screen.fill(BG_COLOR)
    log_rect = pygame.Rect(20, 20, SCREEN_W - 40, SCREEN_H - 100)
    input_rect = pygame.Rect(20, SCREEN_H - 64, SCREEN_W - 40, 44)

    line_h = font.get_height() + 3
    max_lines = log_rect.height // line_h
    wrapped = []
    for text, color in io.entries:
        for w in _wrap(text, font, log_rect.width - 12):
            wrapped.append((w, color))
    visible = wrapped[-max_lines:] if len(wrapped) > max_lines else wrapped
    y = log_rect.top
    for text, color in visible:
        img = font.render(text, True, color)
        screen.blit(img, (log_rect.left, y))
        y += line_h

    pygame.draw.rect(screen, INPUT_BG, input_rect, border_radius=6)
    pygame.draw.rect(screen, INPUT_BORDER, input_rect, width=2, border_radius=6)
    prompt_img = font.render("> " + io.current_input, True, TEXT_COLOR)
    screen.blit(prompt_img, (input_rect.left + 10, input_rect.centery - prompt_img.get_height() // 2))

    pygame.display.flip()


async def main() -> int:
    pygame.init()
    pygame.display.set_caption(GAME_TITLE)
    screen = pygame.display.set_mode((SCREEN_W, SCREEN_H))
    font = pygame.font.SysFont(None, 22)
    clock = pygame.time.Clock()

    io = PygameIO()
    game = Game(io)
    game_task = asyncio.ensure_future(game.run())

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    io.submit()
                elif event.key == pygame.K_BACKSPACE:
                    io.backspace()
            elif event.type == pygame.TEXTINPUT:
                io.feed_text(event.text)

        if game_task.done():
            running = False

        _draw(screen, font, io)
        clock.tick(30)
        await asyncio.sleep(0)

    pygame.quit()
    return 0


if __name__ == "__main__":
    asyncio.run(main())
