"""Items: a base Item plus Weapon, Armor, Consumable, and KeyItem variants."""

from dataclasses import dataclass


@dataclass
class Item:
    name: str
    description: str
    value: int = 0

    def __str__(self) -> str:
        return self.name


@dataclass
class Weapon(Item):
    attack_bonus: int = 0


@dataclass
class Armor(Item):
    defense_bonus: int = 0


@dataclass
class Consumable(Item):
    heal: int = 0
    insight_restore: int = 0

    def use_message(self) -> str:
        return f"You use the {self.name}. {self.description}"


@dataclass
class KeyItem(Item):
    """Required to unlock a specific gated location."""
