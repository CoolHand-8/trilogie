"""Non-player characters: friendly dialogue NPCs and hostile enemies."""

from dataclasses import dataclass, field
from typing import List, Optional

from entities.character import Character
from entities.item import Item


@dataclass
class NPC:
    """A talkable, non-hostile character keyed to a DialogueTree."""

    name: str
    dialogue_key: str
    description: str = ""


class Enemy(Character):
    def __init__(
        self,
        name: str,
        max_hp: int,
        attack: int,
        defense: int = 0,
        level: int = 1,
        xp_reward: int = 10,
        loot: Optional[List[Item]] = None,
        quote: str = "",
    ):
        super().__init__(name=name, max_hp=max_hp, attack=attack, defense=defense, level=level)
        self.xp_reward = xp_reward
        self.loot = loot or []
        self.quote = quote

    def strike(self) -> int:
        return self.attack
