"""Base character stats shared by the player and all NPCs/enemies."""

from dataclasses import dataclass, field


@dataclass
class Character:
    name: str
    max_hp: int
    attack: int
    defense: int = 0
    level: int = 1
    hp: int = field(init=False)

    def __post_init__(self):
        self.hp = self.max_hp

    @property
    def alive(self) -> bool:
        return self.hp > 0

    def take_damage(self, amount: int) -> int:
        """Applies defense mitigation (a hit always lands for at least 1)."""
        if amount <= 0:
            return 0
        mitigated = max(1, amount - self.defense)
        self.hp = max(0, self.hp - mitigated)
        return mitigated

    def heal(self, amount: int) -> int:
        healed = max(0, min(amount, self.max_hp - self.hp))
        self.hp += healed
        return healed
