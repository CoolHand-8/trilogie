"""The player-controlled protagonist: stats, equipment, and XP progression."""

from typing import List, Optional

from core.settings import (
    STARTING_ATTACK,
    STARTING_DEFENSE,
    STARTING_GOLD,
    STARTING_HP,
    STARTING_INSIGHT,
    xp_for_level,
)
from entities.character import Character
from entities.item import Armor, Weapon
from mechanics.inventory import Inventory


class Player(Character):
    def __init__(self, name: str):
        super().__init__(name=name, max_hp=STARTING_HP, attack=STARTING_ATTACK, defense=STARTING_DEFENSE)
        self.xp = 0
        self.gold = STARTING_GOLD
        self.insight = STARTING_INSIGHT
        self.max_insight = STARTING_INSIGHT
        self.inventory = Inventory()
        self.weapon: Optional[Weapon] = None
        self.armor: Optional[Armor] = None

    @property
    def total_attack(self) -> int:
        return self.attack + (self.weapon.attack_bonus if self.weapon else 0)

    @property
    def total_defense(self) -> int:
        return self.defense + (self.armor.defense_bonus if self.armor else 0)

    def take_damage(self, amount: int) -> int:
        if amount <= 0:
            return 0
        mitigated = max(1, amount - self.total_defense)
        self.hp = max(0, self.hp - mitigated)
        return mitigated

    def equip(self, item) -> str:
        if isinstance(item, Weapon):
            self.weapon = item
            return f"You equip the {item.name}. Attack is now {self.total_attack}."
        if isinstance(item, Armor):
            self.armor = item
            return f"You equip the {item.name}. Defense is now {self.total_defense}."
        return f"The {item.name} cannot be equipped."

    def gain_xp(self, amount: int) -> List[str]:
        messages = [f"You gain {amount} XP."]
        self.xp += amount
        while self.xp >= xp_for_level(self.level + 1):
            self.level += 1
            self.max_hp += 8
            self.attack += 2
            self.defense += 1
            self.hp = self.max_hp
            messages.append(f"You reach level {self.level}! Max HP, Attack, and Defense increase.")
        return messages

    def spend_insight(self, amount: int) -> bool:
        if self.insight < amount:
            return False
        self.insight -= amount
        return True

    def restore_insight(self, amount: int) -> None:
        self.insight = min(self.max_insight, self.insight + amount)
