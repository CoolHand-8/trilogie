# The Sin of Fey

A text-based OOP adventure game built from Jesse Almarker's trilogy:
*Esoteric Psychology*, *Phobia*, and *The Green Apple*.

Each book becomes an **Act**; each chapter becomes a **Room** holding a named
**Phobia** (enemy) drawn from that chapter's title. Defeating a Phobia "names"
it and dissolves it. Chakras (Root, Sacral, Solar Plexus, Heart, Throat, Third
Eye, Crown) open as you collect artifacts, letting you use elemental
"Reflect" attacks (Air, Water, Earth, Fire, Spirit) themed on the books'
recurring symbols (the pendulum, mercury, the throat chakra, the green/red
apple).

**Content note:** the trilogy and this game depict trauma, abusive
relationship cycles, substance use, dissociation, and psychosis. Rooms
personify these experiences as Phobias to be understood and named rather
than as villains or diagnoses to be feared; nothing is depicted graphically.

## Run

There are two versions: a terminal (CLI) game and a graphical pygame game.

Quickest way (creates `.venv` and installs everything automatically on first run):

```
./run.sh          # terminal version
./run-gui.sh       # pygame version
```

Manual setup:

```
python3 -m venv .venv
.venv/bin/pip install -e .
.venv/bin/pip install pygame-ce   # only needed for the graphical version

.venv/bin/sin-of-fey              # terminal version, or: .venv/bin/python main.py
.venv/bin/sin-of-fey-gui           # pygame version, or: .venv/bin/python gui_main.py
```

Note: on Python 3.14, plain `pygame` has no prebuilt wheel yet — install the
drop-in, actively-maintained `pygame-ce` fork instead (same `import pygame` API).

### Pygame controls

- Mouse: click any button.
- Keyboard: `c` confront, `r` reflect, `i` item/inventory, `f` flee, `k` chakras,
  `Enter` continue/begin.

## Commands

- Exploration: `look`, `inventory`, `chakras`, `c` (confront/advance), `quit`
- Combat: `c` confront (plain attack), `r` reflect (elemental chakra attack),
  `i` item (heal/restore Insight), `f` flee (rest, partial recovery)

## Structure

- `engine/elements.py` – Air/Water/Earth/Fire/Spirit effectiveness chart
- `engine/chakras.py` – chakra unlock + Insight resource
- `engine/items.py` – Item / KeyItem / Artifact
- `engine/entities.py` – Character / Player / Phobia
- `engine/world.py` – Room / Act / World
- `engine/combat.py` – turn-based combat loop
- `data/story.py` – the three Acts, built from the trilogy's chapters
- `main.py` – CLI game loop
