"""Story data: the world is built from the three books of the trilogy.

Act I  - Esoteric Psychology: A Medical Journal
Act II - Phobia: Psychiatric Science
Act III - The Green Apple: The Sin of Fey
"""

from engine.chakras import Chakra
from engine.elements import Element
from engine.entities import Phobia
from engine.items import Artifact, KeyItem
from engine.world import Act, Room, World


ROOM_REFLECTIONS = {
    "sinister": "The journal is not evidence against you. It is proof that you survived long enough to describe the room.",
    "birds_of_prey": "A swallowed sentence does not disappear. Give it a plain name before it learns to circle overhead.",
    "yin_yang": "Care is not a performance. You can ask what you need without making it a test of someone else's goodness.",
    "scissor_hands": "Safety that cuts away every uneven edge is another kind of cage. Keep one true, imperfect thing.",
    "storm_warning": "Tension, incident, apology, calm: that is a cycle, not proof of love. Naming the pattern is the first door out. You are not responsible for someone else's weather.",
    "human_temple": "A boundary is a door with a handle on your side. It can open, close, and still remain a boundary.",
    "bubonic_plague": "Old alarms are not prophecies. Notice the bell, breathe, and decide whether danger is present now.",
    "hypnotist": "No voice owns your attention without your permission. Return to the details you can verify: floor, breath, name.",
    "sociopathy": "A smile that arrives late may be frightening, but you do not have to solve its motive to protect your peace.",
    "insomnia": "Rest is not earned by exhausting yourself. Let the unanswered thought sit beside the clock without feeding it.",
    "malaria": "The body remembers distress in heat, pulse, and breath. Treat the signal kindly before demanding an explanation.",
    "last_call": "Relief that comes from a bottle is still relief, and wanting it is not a moral failure. Relapse is a data point, not a verdict. The door to help stays open on every attempt.",
    "static_signal": "What the static insists is not always what is true, and doubting it does not make you dangerous or broken. Keep one hand on something real -- a name, a texture, a trusted voice -- while you sort signal from noise.",
    "shame": "A date can be kept without becoming a prison. The past happened; it does not get to narrate every room after it.",
    "it_thing": "Naming a fear shrinks its territory. A name is not a verdict, only a place to begin speaking clearly.",
    "diamond_of_the_mind": "Precision can illuminate or wound. Let this thought be a tool in your hand, not a blade turned inward.",
    "sleep_state": "Between waking and sleep, images borrow the weight of facts. Wait for morning before giving them authority.",
    "wheel_of_cheese": "Memory may repeat itself, but each return can carry one new detail. Keep the useful detail and release the loop.",
    "grimwitch": "Symbols can be playful without becoming commands. You decide which meanings deserve a place in your life.",
    "mercury_therapy": "An anchor is not a chain. Hold the memory long enough to learn from it, then set it down deliberately.",
    "igloo": "Half-consciousness is a threshold, not a failure. Warm the part of you that wants certainty before crossing it.",
    "red_apple": "Wanting is information, not wrongdoing. Pause, choose freely, and let your choice belong to you.",
    "sin_of_fey": "There is no purity trial at the center of the garden. You are allowed to be seen, to choose, and to remain whole.",
}


def build_world() -> World:
    act1 = Act(
        title="Book I: Esoteric Psychology",
        book="A Medical Journal",
        rooms=[
            Room(
                key="sinister",
                title='Time Spent With "Sinister"',
                flavor="A cold study lined with journals. Something sits in the "
                "dark corner, calling itself Sinister.",
                phobia=Phobia(
                    "Sinister", 18, Element.EARTH, 4,
                    "You wrote me down, but you never looked at me.",
                ),
                item=Artifact(
                    "Silent Pendulum",
                    "A pendulum that swings toward what is unspoken. Grants a Water reflection.",
                    element=Element.WATER, attack_bonus=1,
                ),
            ),
            Room(
                key="birds_of_prey",
                title="Birds of Prey",
                flavor="Crows circle a throat-shaped hollow in the ceiling beams.",
                phobia=Phobia(
                    "Birds of Prey", 20, Element.AIR, 5,
                    "Every word you swallowed, we picked from your throat.",
                ),
                item=Artifact(
                    "Throat Chakra Feather",
                    "A feather that opens the Throat chakra. Grants an Air reflection.",
                    element=Element.AIR, attack_bonus=2,
                ),
            ),
            Room(
                key="yin_yang",
                title="Yin and Yang",
                flavor="A room split exactly in half, black tile and white tile.",
                phobia=Phobia(
                    "Unaware", 22, Element.WATER, 5,
                    '"Anything I can do for you?" it asks, meaning nothing.',
                ),
                item=None,
            ),
            Room(
                key="scissor_hands",
                title="Edward Scissor Hands",
                flavor="Shears hang from every wall, snipping at nothing, endlessly.",
                phobia=Phobia(
                    "Scissor Hands", 24, Element.AIR, 6,
                    "I only ever wanted to trim you into something safe.",
                    reward=None,
                ),
                item=KeyItem("Rusted Key", "A small key that smells of the Human Temple."),
            ),
            Room(
                key="storm_warning",
                title="Storm Warning",
                flavor="A kitchen where the barometer never settles; sweetness always follows the thunder.",
                phobia=Phobia(
                    "The Weather", 25, Element.FIRE, 6,
                    "Give it time. The weather always breaks, and I always come back sweet as rain.",
                ),
                item=None,
            ),
            Room(
                key="human_temple",
                title="The Human Temple",
                flavor="A cathedral built from ribs and mucus membrane, humming softly.",
                phobia=Phobia(
                    "The Membrane", 26, Element.WATER, 6,
                    "Every wall you built to keep the world out kept you in, too.",
                ),
                requires_key="Rusted Key",
                item=Artifact(
                    "Reiki Coal", "A warm coal from a healer's hand. Grants a Fire reflection.",
                    element=Element.FIRE, attack_bonus=2,
                ),
            ),
            Room(
                key="bubonic_plague",
                title="The Bubonic Plague",
                flavor="Bells toll in a plague-doctor's ward. The final fear of the book waits.",
                phobia=Phobia(
                    "The Bubonic Plague", 34, Element.EARTH, 8,
                    "I am every old disease you never let die.",
                ),
                item=None,
            ),
        ],
    )

    act2 = Act(
        title="Book II: Phobia",
        book="Psychiatric Science",
        rooms=[
            Room(
                key="hypnotist",
                title="The Hypnotist Is A Maniac",
                flavor="A voice keeps saying 'Sleep' from somewhere behind your own eyes.",
                phobia=Phobia(
                    "The Hypnotist", 24, Element.SPIRIT, 6,
                    'He usually only says, "Don\'t!" But I do.',
                ),
                item=Artifact(
                    "Cracked Pocketwatch", "Stopped at the moment you stopped listening. Grants a Spirit reflection.",
                    element=Element.SPIRIT, attack_bonus=2,
                ),
            ),
            Room(
                key="sociopathy",
                title="Sociopathy",
                flavor="A mirror-hall where every reflection smiles a beat too late.",
                phobia=Phobia(
                    "Sociopathy", 22, Element.FIRE, 6,
                    "I never needed you to feel anything at all.",
                ),
                item=None,
            ),
            Room(
                key="insomnia",
                title="Insomnia",
                flavor="A bedroom where the clock hands spin but the light never changes.",
                phobia=Phobia(
                    "Insomnia", 20, Element.AIR, 7,
                    "Close your eyes. I'll still be counting.",
                ),
                item=KeyItem("Brass Latch", "A latch pried from a door that would not stay shut."),
            ),
            Room(
                key="malaria",
                title="Malaria",
                flavor="A fevered swamp room, humid air thick with a low buzzing.",
                phobia=Phobia(
                    "Malaria", 26, Element.WATER, 7,
                    "You cannot outrun a fever that lives in the blood.",
                ),
                requires_key="Brass Latch",
                item=Artifact(
                    "Quinine Vial", "Bitter medicine turned charm. Heals when used.",
                    heal=14,
                ),
            ),
            Room(
                key="last_call",
                title="Last Call",
                flavor="A quiet bar after closing, one glass catching the last of the light.",
                phobia=Phobia(
                    "Last Call", 27, Element.FIRE, 7,
                    "One more won't count. It never counts, until it's the only thing that does.",
                ),
                item=Artifact(
                    "Amber Token", "A chip kept in a pocket to mark a choice made again today. Heals when used.",
                    heal=10,
                ),
            ),
            Room(
                key="shame",
                title="Shame: Thursday 31 December 2020",
                flavor="A New Year's room where every clock reads the same regret.",
                phobia=Phobia(
                    "Shame", 24, Element.EARTH, 7,
                    "I keep the date so you never have to forget.",
                ),
                item=None,
            ),
            Room(
                key="static_signal",
                title="Static and Signal",
                flavor="A radio room where every station bleeds into the next, and one voice claims to be the true broadcast.",
                phobia=Phobia(
                    "The Static", 29, Element.AIR, 8,
                    "I don't lie to you. I just don't always tell you which channel is real.",
                ),
                item=Artifact(
                    "Grounding Stone", "Smooth and cool, a fixed point to hold while sorting signal from noise. Grants an Earth reflection.",
                    element=Element.EARTH, attack_bonus=2,
                ),
            ),
            Room(
                key="it_thing",
                title='"It" and "Thing"',
                flavor="A room with no nouns, only pronouns pointing at something unseen.",
                phobia=Phobia(
                    "It/Thing", 26, Element.SPIRIT, 7,
                    "You never gave me a name, so I get to be everything.",
                ),
                item=Artifact(
                    "Named Ribbon", "Tying a name to a fear. Grants a bonus to all reflections.",
                    element=Element.SPIRIT, attack_bonus=3,
                ),
            ),
            Room(
                key="diamond_of_the_mind",
                title="The Diamond of the Mind",
                flavor="A crystalline chamber, every facet a different fear crystallized.",
                phobia=Phobia(
                    "The Diamond of the Mind", 40, Element.SPIRIT, 9,
                    "Cut clean enough, and even fear becomes beautiful.",
                ),
                item=None,
            ),
        ],
    )

    act3 = Act(
        title="Book III: The Green Apple",
        book="The Sin of Fey",
        rooms=[
            Room(
                key="sleep_state",
                title="Sleep State",
                flavor="A benchtop kitchen at midnight; a woman's voice calls out and fades.",
                phobia=Phobia(
                    "Sleep State", 22, Element.SPIRIT, 6,
                    "Shit, he won't be at the bottom, will he?",
                ),
                item=Artifact(
                    "Nightlight Sigil", "A small sigil that steadies half-waking dreams. Grants an Earth reflection.",
                    element=Element.EARTH, attack_bonus=2,
                ),
            ),
            Room(
                key="wheel_of_cheese",
                title="The Wheel of Cheese and the Great Dementia",
                flavor="A slowly turning wheel, each wedge a forgotten memory.",
                phobia=Phobia(
                    "The Great Dementia", 26, Element.EARTH, 7,
                    "Round and round; you already told me this, and forgot.",
                ),
                item=None,
            ),
            Room(
                key="grimwitch",
                title="Grimwitch the Warlock",
                flavor="A crooked garden shed full of jarred symbols and burnt sigils.",
                phobia=Phobia(
                    "Grimwitch the Warlock", 30, Element.FIRE, 8,
                    'Look at the symbols and don\'t worry, circus boy.',
                ),
                item=KeyItem("Warlock's Sigil", "A charm pried from Grimwitch's shed."),
            ),
            Room(
                key="mercury_therapy",
                title="Mercury and the Therapy: Memory Anchors",
                flavor="Silver beads of mercury roll across a therapist's low table.",
                phobia=Phobia(
                    "Mercury", 28, Element.WATER, 8,
                    "I was in the womb before you had a name for fear.",
                ),
                requires_key="Warlock's Sigil",
                item=Artifact(
                    "Memory Anchor", "A weighted charm that holds a memory steady. Heals and restores Insight.",
                    heal=10, insight_restore=10,
                ),
            ),
            Room(
                key="igloo",
                title="Semiconsciousness and the Igloo",
                flavor="A room of packed snow-brick, warm at the core, numbing at the edge.",
                phobia=Phobia(
                    "Semiconsciousness", 30, Element.AIR, 8,
                    "Halfway asleep, halfway awake: I live in the seam.",
                ),
                item=None,
            ),
            Room(
                key="red_apple",
                title="Red Apple",
                flavor="An orchard row of red apples, each one a small, ordinary temptation.",
                phobia=Phobia(
                    "Red Apple", 28, Element.FIRE, 8,
                    "I am only what you were always allowed to want.",
                ),
                item=Artifact(
                    "Seed of the Red Apple", "Bitten and understood rather than feared. Grants a bonus to all reflections.",
                    element=Element.SPIRIT, attack_bonus=3,
                ),
            ),
            Room(
                key="sin_of_fey",
                title="The Sin of Fey",
                flavor="The garden itself: the green apple hangs untouched, the serpent waiting "
                "not to tempt you but to be understood.",
                phobia=Phobia(
                    "The Sin of Fey", 50, Element.SPIRIT, 10,
                    "I am not the sin. I am only the sight of yourself, unguarded.",
                ),
                item=None,
            ),
        ],
    )

    world = World(acts=[act1, act2, act3])
    for act in world.acts:
        for room in act.rooms:
            room.reflection = ROOM_REFLECTIONS[room.key]
    return world
