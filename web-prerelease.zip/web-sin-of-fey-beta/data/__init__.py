"""Data package: story content built from the trilogy's chapters."""
