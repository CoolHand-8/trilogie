"""Reusable drawing widgets: buttons, panels, progress bars, wrapped text."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, List, Optional, Tuple

import pygame

from .theme import (
    Fonts,
    GOLD,
    HP_BAD,
    HP_GOOD,
    HP_MID,
    PANEL_BG,
    PANEL_BORDER,
    TEXT_DIM,
    TEXT_MAIN,
)


def wrap_text(text: str, font: pygame.font.Font, max_width: int) -> List[str]:
    lines = []
    for raw_line in text.split("\n"):
        words = raw_line.split(" ")
        current = ""
        for word in words:
            trial = f"{current} {word}".strip()
            if font.size(trial)[0] <= max_width or not current:
                current = trial
            else:
                lines.append(current)
                current = word
        lines.append(current)
    return lines


def draw_text_block(
    surface: pygame.Surface,
    text: str,
    font: pygame.font.Font,
    color,
    rect: pygame.Rect,
    line_spacing: int = 4,
) -> int:
    """Draws wrapped text inside rect, returns the height used."""
    lines = wrap_text(text, font, rect.width)
    y = rect.top
    for line in lines:
        img = font.render(line, True, color)
        if y + img.get_height() > rect.bottom:
            break
        surface.blit(img, (rect.left, y))
        y += img.get_height() + line_spacing
    return y - rect.top


def draw_panel(surface: pygame.Surface, rect: pygame.Rect, glow: bool = False) -> None:
    pygame.draw.rect(surface, (7, 5, 13), rect.move(0, 4), border_radius=8)
    pygame.draw.rect(surface, PANEL_BG, rect, border_radius=8)
    border_color = GOLD if glow else PANEL_BORDER
    pygame.draw.rect(surface, border_color, rect, width=2, border_radius=8)


def draw_bar(
    surface: pygame.Surface,
    rect: pygame.Rect,
    ratio: float,
    color,
    bg=(40, 34, 52),
    label: Optional[str] = None,
    font: Optional[pygame.font.Font] = None,
) -> None:
    ratio = max(0.0, min(1.0, ratio))
    pygame.draw.rect(surface, bg, rect, border_radius=6)
    if ratio > 0:
        fill_rect = pygame.Rect(rect.left, rect.top, int(rect.width * ratio), rect.height)
        pygame.draw.rect(surface, color, fill_rect, border_radius=6)
    pygame.draw.rect(surface, (10, 8, 16), rect, width=1, border_radius=6)
    if label and font:
        img = font.render(label, True, TEXT_MAIN)
        surface.blit(img, img.get_rect(center=rect.center))


def hp_color(ratio: float) -> Tuple[int, int, int]:
    if ratio > 0.55:
        return HP_GOOD
    if ratio > 0.25:
        return HP_MID
    return HP_BAD


def layout_row(count: int, rect: pygame.Rect, height: int = 54, gap: int = 16) -> List[pygame.Rect]:
    if count <= 0:
        return []
    width = (rect.width - gap * (count - 1)) / count
    rects = []
    x = rect.left
    for _ in range(count):
        rects.append(pygame.Rect(int(x), rect.top, int(width), height))
        x += width + gap
    return rects


@dataclass
class Button:
    rect: pygame.Rect
    label: str
    action: Callable[[], None]
    hotkey: Optional[int] = None  # a pygame key constant
    enabled: bool = True
    subtitle: str = ""

    def draw(self, surface: pygame.Surface, mouse_pos) -> None:
        hovered = self.enabled and self.rect.collidepoint(mouse_pos)
        base = (54, 44, 74) if self.enabled else (32, 28, 40)
        if hovered:
            base = (78, 62, 104)
        shadow = pygame.Rect(self.rect.left, self.rect.top + 4, self.rect.width, self.rect.height)
        pygame.draw.rect(surface, (8, 6, 15), shadow, border_radius=8)
        pygame.draw.rect(surface, base, self.rect, border_radius=8)
        border = GOLD if hovered else PANEL_BORDER
        pygame.draw.rect(surface, border, self.rect, width=2, border_radius=8)
        color = TEXT_MAIN if self.enabled else TEXT_DIM
        img = Fonts.button.render(self.label, True, color)
        if self.subtitle:
            sub_img = Fonts.small.render(self.subtitle, True, TEXT_DIM)
            total_h = img.get_height() + sub_img.get_height() + 2
            top = self.rect.centery - total_h // 2
            surface.blit(img, img.get_rect(centerx=self.rect.centerx, top=top))
            surface.blit(sub_img, sub_img.get_rect(centerx=self.rect.centerx, top=top + img.get_height() + 2))
        else:
            surface.blit(img, img.get_rect(center=self.rect.center))

    def handle_click(self, pos) -> bool:
        if self.enabled and self.rect.collidepoint(pos):
            self.action()
            return True
        return False

    def handle_key(self, key) -> bool:
        if self.enabled and self.hotkey is not None and key == self.hotkey:
            self.action()
            return True
        return False
