"""Procedural item "art": since the trilogy has no bespoke item illustrations
yet, each item gets a stylized vector icon (gem, vial, or key) drawn at
whatever size is requested, so it can appear small in a list row and large
in a detail/inspect panel without needing raster art assets."""

from __future__ import annotations

import math

import pygame

from engine.elements import Element
from engine.items import Artifact, KeyItem

from .theme import ELEMENT_COLORS, GOLD

NEUTRAL_TONIC = (150, 210, 190)


def _element_of(item) -> Element:
    return getattr(item, "element", None)


def _lighten(color, amount: float):
    return tuple(min(255, int(c + (255 - c) * amount)) for c in color)


def _darken(color, amount: float):
    return tuple(max(0, int(c * (1 - amount))) for c in color)


def render_item_icon(item, size: int) -> pygame.Surface:
    """Returns a size x size RGBA surface with a procedural icon for `item`."""
    surf = pygame.Surface((size, size), pygame.SRCALPHA)
    center = (size // 2, size // 2)

    if isinstance(item, KeyItem):
        _draw_key(surf, center, size)
    elif isinstance(item, Artifact) and _element_of(item) is not None:
        _draw_gem(surf, center, size, ELEMENT_COLORS[item.element], item.element)
    else:
        _draw_vial(surf, center, size)

    return surf


def _glow(surf, center, size, color, rings=3):
    glow_layer = pygame.Surface(surf.get_size(), pygame.SRCALPHA)
    for ring in range(rings, 0, -1):
        radius = int(size * 0.5 * (ring / rings))
        alpha = int(50 / ring)
        pygame.draw.circle(glow_layer, (*color, alpha), center, radius)
    surf.blit(glow_layer, (0, 0))


def _draw_gem(surf, center, size, color, element: Element):
    _glow(surf, center, size, color)
    r = size * 0.32
    cx, cy = center
    points = [
        (cx, cy - r * 1.15),
        (cx + r * 0.85, cy - r * 0.25),
        (cx + r * 0.55, cy + r * 0.95),
        (cx - r * 0.55, cy + r * 0.95),
        (cx - r * 0.85, cy - r * 0.25),
    ]
    pygame.draw.polygon(surf, _darken(color, 0.35), points)
    facet = [
        (cx, cy - r * 1.15),
        (cx + r * 0.85, cy - r * 0.25),
        (cx, cy + r * 0.15),
        (cx - r * 0.85, cy - r * 0.25),
    ]
    pygame.draw.polygon(surf, _lighten(color, 0.25), facet)
    pygame.draw.polygon(surf, (18, 14, 24), points, width=max(1, size // 64))

    symbol_color = (255, 255, 255, 210)
    sym = pygame.Surface(surf.get_size(), pygame.SRCALPHA)
    if element == Element.FIRE:
        for i in range(3):
            offset = (i - 1) * r * 0.3
            pygame.draw.polygon(sym, symbol_color, [
                (cx + offset, cy + r * 0.35), (cx + offset - r * 0.1, cy - r * 0.05),
                (cx + offset, cy - r * 0.3), (cx + offset + r * 0.1, cy - r * 0.05),
            ])
    elif element == Element.WATER:
        pygame.draw.circle(sym, symbol_color, (cx, int(cy + r * 0.1)), int(r * 0.28), width=max(1, size // 48))
        pygame.draw.polygon(sym, symbol_color, [
            (cx, cy - r * 0.5), (cx - r * 0.2, cy - r * 0.05), (cx + r * 0.2, cy - r * 0.05),
        ])
    elif element == Element.AIR:
        for i, dy in enumerate((-0.2, 0.05, 0.3)):
            pygame.draw.arc(sym, symbol_color, (cx - r * 0.4, cy + r * dy - r * 0.15, r * 0.8, r * 0.3),
                             math.pi * 0.1, math.pi * 0.9, width=max(1, size // 64))
    elif element == Element.EARTH:
        pygame.draw.polygon(sym, symbol_color, [
            (cx, cy - r * 0.35), (cx + r * 0.35, cy + r * 0.25), (cx - r * 0.35, cy + r * 0.25),
        ], width=max(1, size // 48))
    else:  # SPIRIT
        pygame.draw.circle(sym, symbol_color, center, int(r * 0.12))
        for i in range(6):
            angle = math.tau * i / 6
            pygame.draw.line(sym, symbol_color, center,
                              (cx + math.cos(angle) * r * 0.4, cy + math.sin(angle) * r * 0.4),
                              width=max(1, size // 64))
    surf.blit(sym, (0, 0))


def _draw_vial(surf, center, size):
    _glow(surf, center, size, NEUTRAL_TONIC)
    cx, cy = center
    w, h = size * 0.28, size * 0.46
    body = pygame.Rect(0, 0, w, h)
    body.center = (cx, cy + size * 0.08)
    pygame.draw.rect(surf, _darken(NEUTRAL_TONIC, 0.15), body, border_radius=int(w * 0.3))
    liquid = body.inflate(-size * 0.05, 0)
    liquid.height = int(body.height * 0.6)
    liquid.bottom = body.bottom - int(size * 0.02)
    pygame.draw.rect(surf, NEUTRAL_TONIC, liquid, border_radius=int(w * 0.25))
    neck = pygame.Rect(0, 0, w * 0.4, size * 0.14)
    neck.midbottom = (cx, body.top + 2)
    pygame.draw.rect(surf, (70, 60, 50), neck)
    cork = pygame.Rect(0, 0, w * 0.5, size * 0.08)
    cork.midbottom = neck.midtop
    pygame.draw.rect(surf, (150, 110, 70), cork, border_radius=3)
    pygame.draw.rect(surf, (20, 16, 14), body, width=max(1, size // 64), border_radius=int(w * 0.3))
    for i in range(3):
        bx = cx - w * 0.15 + i * w * 0.15
        by = liquid.bottom - (size * 0.05) - (i * size * 0.06)
        pygame.draw.circle(surf, _lighten(NEUTRAL_TONIC, 0.4), (int(bx), int(by)), max(1, int(size * 0.02)))


def _draw_key(surf, center, size):
    _glow(surf, center, size, GOLD)
    cx, cy = center
    r = size * 0.16
    ring_center = (cx, cy - size * 0.22)
    pygame.draw.circle(surf, GOLD, ring_center, r, width=max(2, size // 24))
    shaft_top = cy - size * 0.22 + r
    shaft = pygame.Rect(0, 0, size * 0.08, size * 0.42)
    shaft.midtop = (cx, shaft_top)
    pygame.draw.rect(surf, GOLD, shaft)
    tooth_a = pygame.Rect(0, 0, size * 0.16, size * 0.07)
    tooth_a.midtop = (cx + size * 0.04, shaft.bottom - size * 0.14)
    tooth_b = pygame.Rect(0, 0, size * 0.12, size * 0.07)
    tooth_b.midtop = (cx + size * 0.04, shaft.bottom - size * 0.03)
    pygame.draw.rect(surf, GOLD, tooth_a)
    pygame.draw.rect(surf, GOLD, tooth_b)
    pygame.draw.circle(surf, (30, 24, 12), ring_center, r * 0.45)
