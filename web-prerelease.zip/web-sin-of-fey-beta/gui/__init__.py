"""GUI package for the pygame version of The Sin of Fey."""
