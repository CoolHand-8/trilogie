"""The pygame application: title screen, exploration, combat, win/lose scenes."""

from __future__ import annotations

import asyncio
import sys
import math
from pathlib import Path

import pygame

from data.story import build_world
from engine.chakras import CHAKRA_ORDER
from engine.elements import Element
from engine.entities import Player

from .combat_controller import CombatController
from .effects import DreadAudio, FloatingText, MessageLog, PostProcessOverlay, ScreenShake
from .item_art import render_item_icon
from .theme import (
    BG_BOTTOM,
    BG_TOP,
    ELEMENT_COLORS,
    Fonts,
    GOLD,
    HP_BAD,
    HP_GOOD,
    INSIGHT_COLOR,
    PANEL_BORDER,
    SCREEN_H,
    SCREEN_W,
    TEXT_ACCENT,
    TEXT_DIM,
    TEXT_MAIN,
    draw_atmosphere,
)
from .widgets import Button, draw_bar, draw_panel, draw_text_block, hp_color, layout_row, wrap_text

HUD_RECT = pygame.Rect(30, 20, SCREEN_W - 60, 66)
CHAKRA_RECT = pygame.Rect(30, 94, SCREEN_W - 60, 34)
MAIN_RECT = pygame.Rect(30, 140, SCREEN_W - 60, 300)
LOG_RECT = pygame.Rect(30, 452, SCREEN_W - 60, 168)
BUTTON_ROW = pygame.Rect(30, 634, SCREEN_W - 60, 56)
MARKETING_DIR = Path(__file__).resolve().parents[2] / "marketing"
COVER_FILES = (
    "EsotericPsychology-MC-638605192599199432.png",
    "Phobia-MC-638651228891239175.png",
    "TheGreenApple-MC-638654454269040179.png",
)

PLAYER_ANCHOR = (230, 330)
ENEMY_ANCHOR = (870, 240)

KIND_COLOR = {
    "info": TEXT_MAIN,
    "player_hit": HP_GOOD,
    "enemy_hit": HP_BAD,
    "warn": GOLD,
}


def _open_next_chakra(player: Player):
    for chakra in CHAKRA_ORDER:
        if chakra not in player.chakras.opened and len(player.artifacts) >= 1:
            if player.chakras.open_chakra(chakra):
                return chakra
            return None
    return None


class App:
    def __init__(self):
        pygame.init()
        Fonts.load()
        self.fullscreen = False
        self.windowed_size = (1100, 720)
        self.screen = pygame.display.set_mode(self.windowed_size, pygame.RESIZABLE)
        pygame.display.set_caption("The Sin of Fey")
        self.canvas = pygame.Surface((SCREEN_W, SCREEN_H))
        self.viewport = pygame.Rect(0, 0, SCREEN_W, SCREEN_H)
        self._update_viewport()
        self.mouse_pos = (0, 0)
        self.clock = pygame.time.Clock()
        self.log = MessageLog()
        self.shake = ScreenShake()
        self.overlay = PostProcessOverlay()
        self.audio = DreadAudio()
        self.floats = []
        self.visual_time = 0.0
        self.world = None
        self.player = None
        self.running = True
        self.covers = self._load_covers()
        self.scene = TitleScene(self)

    def _set_display_mode(self):
        if self.fullscreen:
            self.screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
        else:
            self.screen = pygame.display.set_mode(self.windowed_size, pygame.RESIZABLE)

    def _update_viewport(self):
        width, height = self.screen.get_size()
        scale = min(width / SCREEN_W, height / SCREEN_H)
        view_width = max(1, round(SCREEN_W * scale))
        view_height = max(1, round(SCREEN_H * scale))
        self.viewport = pygame.Rect((width - view_width) // 2, (height - view_height) // 2, view_width, view_height)

    def to_canvas_pos(self, position):
        self._update_viewport()
        x = (position[0] - self.viewport.left) * SCREEN_W / self.viewport.width
        y = (position[1] - self.viewport.top) * SCREEN_H / self.viewport.height
        return (
            min(SCREEN_W - 1, max(0, round(x))),
            min(SCREEN_H - 1, max(0, round(y))),
        )

    def quit(self):
        self.running = False

    def toggle_fullscreen(self):
        self.fullscreen = not self.fullscreen
        self._set_display_mode()

    def _load_covers(self):
        covers = []
        for filename in COVER_FILES:
            path = MARKETING_DIR / filename
            if path.is_file():
                image = pygame.image.load(path).convert_alpha()
                covers.append(pygame.transform.smoothscale(image, (180, 180)))
        return covers

    def start_new_game(self):
        self.world = build_world()
        self.player = Player("Jesse")
        self.log = MessageLog()
        self.log.add(
            "You carry three books worth of fear: Esoteric Psychology, Phobia, "
            "and The Green Apple. Each room is a chapter. Naming a fear is how you win.",
            TEXT_DIM,
        )
        self.scene = ExploreScene(self)

    def spawn_float(self, text, pos, color):
        self.floats.append(FloatingText(text, pos, color))

    async def run(self):
        while self.running:
            dt = self.clock.tick(60) / 1000
            self.visual_time += dt
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    self.quit()
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_F11:
                    self.toggle_fullscreen()
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_m:
                    sound_on = self.audio.toggle()
                    self.log.add(f"Dread sounds {'on' if sound_on else 'muted'}.", TEXT_DIM)
                elif event.type == pygame.VIDEORESIZE and not self.fullscreen:
                    self.windowed_size = event.size
                    self._set_display_mode()
                else:
                    if hasattr(event, "pos"):
                        event = pygame.event.Event(event.type, {**event.dict, "pos": self.to_canvas_pos(event.pos)})
                    self.scene.handle_event(event)

            self.mouse_pos = self.to_canvas_pos(pygame.mouse.get_pos())
            self.floats = [f for f in self.floats if f.update(dt)]
            self.scene.update(dt)

            self.canvas.fill((0, 0, 0))
            draw_atmosphere(self.canvas, self.visual_time, self.shake.trauma)
            self.scene.draw(self.canvas)
            for f in self.floats:
                f.draw(self.canvas)

            offset = self.shake.update(dt)
            self._update_viewport()
            self.screen.fill((8, 6, 14))
            shaken_viewport = self.viewport.move(
                int(offset[0] * self.viewport.width / SCREEN_W),
                int(offset[1] * self.viewport.height / SCREEN_H),
            )
            self.overlay.draw(self.screen, shaken_viewport, self.canvas, self.visual_time, self.shake.trauma)
            pygame.display.flip()
            await asyncio.sleep(0)
        pygame.quit()

    # --- shared HUD -------------------------------------------------
    def draw_hud(self, surface):
        if not self.player:
            return
        draw_panel(surface, HUD_RECT)
        p = self.player
        name_img = Fonts.heading.render(p.name, True, TEXT_MAIN)
        surface.blit(name_img, (HUD_RECT.left + 16, HUD_RECT.top + 8))

        hp_rect = pygame.Rect(HUD_RECT.left + 220, HUD_RECT.top + 12, 340, 20)
        draw_bar(surface, hp_rect, p.hp / p.max_hp, hp_color(p.hp / p.max_hp),
                 label=f"HP {p.hp}/{p.max_hp}", font=Fonts.small)

        insight_rect = pygame.Rect(HUD_RECT.left + 220, HUD_RECT.top + 38, 340, 18)
        ratio = p.chakras.insight / p.chakras.max_insight if p.chakras.max_insight else 0
        draw_bar(surface, insight_rect, ratio, INSIGHT_COLOR,
                 label=f"Insight {p.chakras.insight}/{p.chakras.max_insight}", font=Fonts.small)

        act = self.world.current_act() if self.world else None
        if act:
            metadata_rect = pygame.Rect(HUD_RECT.right - 300, HUD_RECT.top + 8, 284, 38)
            book_img = Fonts.small.render(act.book, True, TEXT_ACCENT)
            surface.blit(book_img, book_img.get_rect(right=metadata_rect.right, top=metadata_rect.top))
            title_line = wrap_text(act.title, Fonts.small, metadata_rect.width)[0]
            title_img = Fonts.small.render(title_line, True, TEXT_DIM)
            surface.blit(title_img, title_img.get_rect(right=metadata_rect.right, bottom=metadata_rect.bottom))

        sound_label = "on" if self.audio.available and not self.audio.muted else "off"
        exit_img = Fonts.small.render(f"Esc exit | F11 window | M sound {sound_label}", True, TEXT_DIM)
        surface.blit(exit_img, exit_img.get_rect(right=HUD_RECT.right - 16, bottom=HUD_RECT.bottom - 6))

        draw_panel(surface, CHAKRA_RECT)
        n = len(CHAKRA_ORDER)
        gap = CHAKRA_RECT.width / n
        for i, chakra in enumerate(CHAKRA_ORDER):
            cx = int(CHAKRA_RECT.left + gap * i + gap / 2)
            cy = CHAKRA_RECT.centery
            opened = chakra in p.chakras.opened
            color = GOLD if opened else (60, 54, 74)
            pygame.draw.circle(surface, color, (cx, cy), 10)
            pygame.draw.circle(surface, PANEL_BORDER, (cx, cy), 10, width=1)
            label = Fonts.small.render(chakra.value, True, TEXT_DIM if not opened else TEXT_MAIN)
            surface.blit(label, label.get_rect(centerx=cx, top=cy + 14))

    def draw_log(self, surface):
        draw_panel(surface, LOG_RECT)
        inner = LOG_RECT.inflate(-24, -20)
        marker = Fonts.small.render("JOURNAL // THE INNER WORLD", True, TEXT_ACCENT)
        surface.blit(marker, (inner.left, inner.top))
        font = Fonts.small
        line_h = font.get_height() + 4
        available_height = inner.height - marker.get_height() - 5
        entries = []
        used_height = 0
        for text, color in reversed(self.log.lines):
            wrapped = wrap_text(text, font, inner.width)
            entry_height = len(wrapped) * line_h
            if used_height + entry_height > available_height:
                break
            entries.append((wrapped, color))
            used_height += entry_height
        entries.reverse()
        y = inner.top + marker.get_height() + 5
        for wrapped_lines, color in entries:
            for wrapped in wrapped_lines:
                img = font.render(wrapped, True, color)
                surface.blit(img, (inner.left, y))
                y += line_h


class Scene:
    def __init__(self, app: App):
        self.app = app
        self.buttons = []

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for b in self.buttons:
                if b.handle_click(event.pos):
                    return
        elif event.type == pygame.KEYDOWN:
            for b in self.buttons:
                if b.handle_key(event.key):
                    return

    def update(self, dt):
        pass

    def draw(self, surface):
        raise NotImplementedError


class TitleScene(Scene):
    def __init__(self, app):
        super().__init__(app)
        btn_rect = pygame.Rect(0, 0, 360, 64)
        btn_rect.center = (SCREEN_W // 2, 560)
        exit_rect = pygame.Rect(0, 0, 180, 64)
        exit_rect.midleft = (btn_rect.right + 18, btn_rect.centery)
        self.buttons = [
            Button(btn_rect, "Begin the Journey", self._begin, hotkey=pygame.K_RETURN),
            Button(exit_rect, "Exit", app.quit, hotkey=pygame.K_ESCAPE),
        ]

    def _begin(self):
        self.app.start_new_game()

    def draw(self, surface):
        sigil = pygame.Surface((360, 360), pygame.SRCALPHA)
        center = (180, 180)
        for radius, alpha in ((152, 18), (116, 26), (78, 40)):
            pygame.draw.circle(sigil, (*GOLD, alpha), center, radius, width=2)
        for index in range(7):
            angle = self.app.visual_time * 0.24 + index * math.tau / 7
            point = (int(center[0] + math.cos(angle) * 132), int(center[1] + math.sin(angle) * 132))
            pygame.draw.circle(sigil, (*TEXT_ACCENT, 120), point, 4)
        surface.blit(sigil, sigil.get_rect(center=(SCREEN_W // 2, 275)))
        title = Fonts.title.render("THE SIN OF FEY", True, GOLD)
        surface.blit(title, title.get_rect(centerx=SCREEN_W // 2, top=120))
        subtitle = Fonts.body.render(
            "a journey through Esoteric Psychology, Phobia, and The Green Apple",
            True, TEXT_ACCENT,
        )
        surface.blit(subtitle, subtitle.get_rect(centerx=SCREEN_W // 2, top=190))

        for index, cover in enumerate(self.app.covers):
            x = SCREEN_W // 2 - 290 + index * 200
            frame = pygame.Rect(x - 5, 227, 190, 190)
            pygame.draw.rect(surface, (9, 7, 16), frame.move(0, 5), border_radius=4)
            pygame.draw.rect(surface, GOLD if index == 1 else PANEL_BORDER, frame, width=2, border_radius=4)
            surface.blit(cover, (x, 232))

        blurb_rect = pygame.Rect(60, 425, SCREEN_W - 120, 72)
        draw_text_block(
            surface,
            "Three books of fear wait for you, each chapter a room, each room a "
            "fear given a name. Confront your fears directly, or reflect their "
            "own nature back at them once you have opened the right chakra. "
            "Name every fear across all three books, and the Sin of Fey will "
            "dissolve into ordinary sunlight.",
            Fonts.small, TEXT_MAIN, blurb_rect,
        )
        for b in self.buttons:
            b.draw(surface, self.app.mouse_pos)


class ExploreScene(Scene):
    def __init__(self, app):
        super().__init__(app)
        self.player = app.player
        self.act = app.world.current_act()
        self.room = None
        self.show_inventory = False
        self.show_chakras = False
        self.selected_item = None
        self._inventory_rows = []
        self._icon_cache = {}
        self._enter_current_room()

    def _enter_current_room(self):
        room = self.act.current()
        while room.is_locked(self.player):
            self.app.log.add(
                f'"{room.title}" stays sealed without its key. You leave it behind for now.',
                TEXT_DIM,
            )
            room.cleared = True  # sealed and skipped: keep act completion tracking consistent
            if not self.act.has_next():
                break
            room = self.act.advance()
        self.room = room
        if not room.visited:
            room.visited = True
            self.app.log.add(f"== {room.title} ==", GOLD)
            self.app.log.add(room.flavor, TEXT_MAIN)
        self._rebuild_buttons()

    def _rebuild_buttons(self):
        room = self.room
        buttons = []
        if room.phobia and room.phobia.alive and not room.cleared:
            buttons.append(Button(pygame.Rect(0, 0, 0, 0), "Confront", self._start_combat,
                                   hotkey=pygame.K_c, subtitle=f"vs {room.phobia.name}"))
        if room.reflection and not room.grounded:
            buttons.append(Button(pygame.Rect(0, 0, 0, 0), "Ground", self._ground,
                                   hotkey=pygame.K_g, subtitle="recover 5 Insight"))
        elif room.item:
            buttons.append(Button(pygame.Rect(0, 0, 0, 0), "Take Item", self._take_item,
                                   hotkey=pygame.K_t, subtitle=room.item.name))
        else:
            label = "Proceed" if not self.act.has_next() and self.act.is_complete() else "Continue"
            buttons.append(Button(pygame.Rect(0, 0, 0, 0), label, self._continue, hotkey=pygame.K_RETURN))
        buttons.append(Button(pygame.Rect(0, 0, 0, 0), "Inventory", self._toggle_inventory, hotkey=pygame.K_i))
        buttons.append(Button(pygame.Rect(0, 0, 0, 0), "Chakras", self._toggle_chakras, hotkey=pygame.K_k))
        rects = layout_row(len(buttons), BUTTON_ROW)
        for b, r in zip(buttons, rects):
            b.rect = r
        self.buttons = buttons

    def _ground(self):
        self.room.grounded = True
        self.player.chakras.restore(5)
        self.app.log.add(self.room.reflection, TEXT_ACCENT)
        self.app.log.add("You recover 5 Insight by taking a moment to ground yourself.", INSIGHT_COLOR)
        self._rebuild_buttons()

    def _get_icon(self, item, size):
        key = (id(item), size)
        icon = self._icon_cache.get(key)
        if icon is None:
            icon = render_item_icon(item, size)
            self._icon_cache[key] = icon
        return icon

    def _select_item(self, item):
        self.selected_item = item

    def _toggle_inventory(self):
        self.show_inventory = not self.show_inventory
        self.show_chakras = False
        if self.show_inventory and self.player.inventory and self.selected_item not in self.player.inventory:
            self.selected_item = self.player.inventory[0]

    def _toggle_chakras(self):
        self.show_chakras = not self.show_chakras
        self.show_inventory = False

    def _start_combat(self):
        self.app.scene = CombatScene(self.app, self.room, self)

    def _take_item(self):
        item = self.room.item
        self.room.item = None
        self.player.add_item(item)
        self.app.log.add(f"You take the {item.name}. {item.description}", GOLD)
        opened = _open_next_chakra(self.player)
        if opened:
            self.app.log.add(f"A new chakra opens within you: {opened.value}.", INSIGHT_COLOR)
        self.room.cleared = True
        self._rebuild_buttons()

    def _continue(self):
        prev_book = self.act.book
        if self.act.has_next():
            self.act.advance()
            self._enter_current_room()
            return
        if self.app.world.is_final_act():
            self.app.scene = WinScene(self.app)
            return
        self.app.world.next_act()
        self.act = self.app.world.current_act()
        self.app.log.add(f"You close the book on {prev_book}. Turning the page...", TEXT_ACCENT)
        self._enter_current_room()

    def draw(self, surface):
        self.app.draw_hud(surface)
        self._draw_room_pressure(surface)
        draw_panel(surface, MAIN_RECT)
        inner = MAIN_RECT.inflate(-32, -28)

        if self.show_inventory:
            self._draw_inventory(surface, inner)
        elif self.show_chakras:
            self._draw_chakras(surface, inner)
        else:
            title_img = Fonts.heading.render(self.room.title, True, GOLD)
            surface.blit(title_img, (inner.left, inner.top))
            body_rect = pygame.Rect(inner.left, inner.top + 44, inner.width, inner.height - 44)
            draw_text_block(surface, self.room.flavor, Fonts.body, TEXT_MAIN, body_rect)
            if self.room.phobia and self.room.phobia.alive and not self.room.cleared:
                warn = Fonts.small.render(
                    f"A fear lingers here: {self.room.phobia.name} ({self.room.phobia.element})",
                    True, ELEMENT_COLORS[self.room.phobia.element],
                )
                surface.blit(warn, (inner.left, inner.bottom - 22))

        self.app.draw_log(surface)
        mouse = pygame.mouse.get_pos()
        for b in self.buttons:
            b.draw(surface, self.app.mouse_pos)

    def _draw_room_pressure(self, surface):
        if not self.room.phobia or self.room.cleared:
            return
        color = ELEMENT_COLORS[self.room.phobia.element]
        veil = pygame.Surface(MAIN_RECT.size, pygame.SRCALPHA)
        for radius, alpha in ((250, 18), (180, 24), (110, 32)):
            pygame.draw.ellipse(veil, (*color, alpha), (MAIN_RECT.width - radius - 35, 35, radius * 2, radius))
        surface.blit(veil, MAIN_RECT.topleft)
        for index in range(8):
            x = MAIN_RECT.right - 38 - index * 46
            y = MAIN_RECT.top + 26 + int(math.sin(self.app.visual_time * 1.5 + index) * 10)
            pygame.draw.circle(surface, (*color, 115), (x, y), 2 + index % 3)

    def _draw_inventory(self, surface, inner):
        title = Fonts.heading.render("Inventory", True, GOLD)
        surface.blit(title, (inner.left, inner.top))
        self._inventory_rows = []
        if not self.player.inventory:
            empty = Fonts.body.render("Your pockets are empty.", True, TEXT_DIM)
            surface.blit(empty, (inner.left, inner.top + 44))
            return

        list_width = int(inner.width * 0.42)
        list_rect = pygame.Rect(inner.left, inner.top + 44, list_width, inner.height - 44)
        detail_rect = pygame.Rect(list_rect.right + 24, inner.top + 44,
                                   inner.width - list_width - 24, inner.height - 44)

        row_h = 56
        y = list_rect.top
        for item in self.player.inventory:
            row = pygame.Rect(list_rect.left, y, list_rect.width, row_h - 8)
            selected = item is self.selected_item
            if selected:
                pygame.draw.rect(surface, (60, 48, 84), row, border_radius=6)
                pygame.draw.rect(surface, GOLD, row, width=2, border_radius=6)
            icon = self._get_icon(item, row.height - 8)
            surface.blit(icon, (row.left + 4, row.top + 4))
            name_img = Fonts.small.render(item.name, True, TEXT_MAIN if selected else TEXT_DIM)
            surface.blit(name_img, (row.left + row.height + 8, row.top + row.height // 2 - name_img.get_height() // 2))
            self._inventory_rows.append((row, item))
            y += row_h
            if row.bottom > list_rect.bottom:
                break

        if self.selected_item is not None:
            icon_size = min(detail_rect.width, 200)
            big_icon = self._get_icon(self.selected_item, icon_size)
            icon_rect = big_icon.get_rect(top=detail_rect.top, centerx=detail_rect.centerx)
            surface.blit(big_icon, icon_rect)
            name_img = Fonts.heading.render(self.selected_item.name, True, GOLD)
            surface.blit(name_img, name_img.get_rect(centerx=detail_rect.centerx, top=icon_rect.bottom + 10))
            desc_rect = pygame.Rect(detail_rect.left, icon_rect.bottom + 44, detail_rect.width,
                                     detail_rect.bottom - (icon_rect.bottom + 44))
            draw_text_block(surface, self.selected_item.description, Fonts.small, TEXT_MAIN, desc_rect)

    def handle_event(self, event):
        if self.show_inventory and event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for row, item in self._inventory_rows:
                if row.collidepoint(event.pos):
                    self._select_item(item)
                    return
        super().handle_event(event)

    def _draw_chakras(self, surface, inner):
        title = Fonts.heading.render("Chakras", True, GOLD)
        surface.blit(title, (inner.left, inner.top))
        body = Fonts.body.render(self.player.chakras.progress_str(), True, TEXT_MAIN)
        surface.blit(body, (inner.left, inner.top + 50))
        hint = Fonts.small.render(
            "Opened chakras power elemental Reflect attacks in combat.", True, TEXT_DIM,
        )
        surface.blit(hint, (inner.left, inner.top + 90))


class CombatScene(Scene):
    def __init__(self, app, room, return_scene):
        super().__init__(app)
        self.room = room
        self.phobia = room.phobia
        self.player = app.player
        self.return_scene = return_scene
        self.controller = CombatController(self.player, self.phobia)
        self.pending_end = None
        self.show_items = False
        self.reveal = 0.0
        self.pulse = 0.0
        self.impact = 0.0
        self.impact_color = GOLD
        self.app.log.add(
            f'A fear takes shape: "{self.phobia.name}" ({self.phobia.element}).',
            ELEMENT_COLORS[self.phobia.element],
        )
        self.app.log.add(f'{self.phobia.name} whispers: "{self.phobia.quote}"', TEXT_DIM)
        self.app.log.add(
            "The room draws inward. The air thickens against your skin as the outline learns your name.",
            TEXT_ACCENT,
        )
        self._rebuild_buttons()

    def update(self, dt):
        self.reveal = min(1.0, self.reveal + dt * 0.72)
        self.pulse += dt
        self.impact = max(0.0, self.impact - dt * 1.8)

    def _rebuild_buttons(self):
        if self.pending_end:
            btn = Button(pygame.Rect(0, 0, 0, 0), "Continue", self._resolve_end, hotkey=pygame.K_RETURN)
            rects = layout_row(1, BUTTON_ROW)
            btn.rect = rects[0]
            self.buttons = [btn]
            return

        artifact = self.player.best_reflect_element(self.phobia.element)
        can_reflect = artifact is not None and self.player.chakras.insight >= CombatController.REFLECT_COST
        healing_items = [i for i in self.player.inventory if getattr(i, "heal", 0) or getattr(i, "insight_restore", 0)]

        buttons = [
            Button(pygame.Rect(0, 0, 0, 0), "Confront", self._confront, hotkey=pygame.K_c),
            Button(pygame.Rect(0, 0, 0, 0), "Reflect", self._reflect, hotkey=pygame.K_r,
                   enabled=can_reflect, subtitle=artifact.name if artifact else "no artifact"),
            Button(pygame.Rect(0, 0, 0, 0), "Item", self._toggle_items, hotkey=pygame.K_i,
                   enabled=bool(healing_items)),
            Button(pygame.Rect(0, 0, 0, 0), "Flee", self._flee, hotkey=pygame.K_f),
        ]
        rects = layout_row(len(buttons), BUTTON_ROW)
        for b, r in zip(buttons, rects):
            b.rect = r
        self.buttons = buttons

    def _apply_outcome(self, outcome):
        for text, kind in outcome.lines:
            self.app.log.add(text, KIND_COLOR.get(kind, TEXT_MAIN))
        if outcome.player_damage_dealt:
            self.impact = 1.0
            self.impact_color = INSIGHT_COLOR
            self.app.spawn_float(f"-{outcome.player_damage_dealt}", ENEMY_ANCHOR, HP_GOOD)
        if any(k == "enemy_hit" for _, k in outcome.lines):
            self.impact = 1.0
            self.impact_color = HP_BAD
            self.app.shake.kick(0.5)
            self.app.audio.cry()
            self.app.spawn_float(
                f"-{self.phobia.attack}", PLAYER_ANCHOR, HP_BAD,
            )
        if outcome.ended in ("win", "lose"):
            self.pending_end = outcome.ended
        self.show_items = False
        self._rebuild_buttons()

    def _confront(self):
        self._apply_outcome(self.controller.confront())

    def _reflect(self):
        self._apply_outcome(self.controller.reflect())

    def _toggle_items(self):
        self.show_items = not self.show_items

    def _use_item(self, item):
        self._apply_outcome(self.controller.use_item(item))

    def _flee(self):
        outcome = self.controller.flee()
        for text, kind in outcome.lines:
            self.app.log.add(text, KIND_COLOR.get(kind, TEXT_MAIN))
        if outcome.ended == "lose":
            self.app.scene = GameOverScene(self.app)
            return
        self.app.scene = self.return_scene
        self.return_scene._rebuild_buttons()

    def _resolve_end(self):
        if self.pending_end == "lose":
            self.app.scene = GameOverScene(self.app)
            return
        self.room.cleared = True
        self.return_scene.room = self.room
        self.return_scene._rebuild_buttons()
        self.app.scene = self.return_scene

    def draw(self, surface):
        self.app.draw_hud(surface)
        draw_panel(surface, MAIN_RECT, glow=True)
        inner = MAIN_RECT.inflate(-32, -28)

        if self.show_items and not self.pending_end:
            self._draw_item_menu(surface, inner)
        else:
            elem_color = ELEMENT_COLORS[self.phobia.element]
            self._draw_fear(surface, elem_color)
            self._draw_impact(surface)
            name_img = Fonts.heading.render(self.phobia.name, True, TEXT_MAIN)
            surface.blit(name_img, name_img.get_rect(centerx=ENEMY_ANCHOR[0], top=ENEMY_ANCHOR[1] + 56))
            hp_rect = pygame.Rect(ENEMY_ANCHOR[0] - 120, ENEMY_ANCHOR[1] + 90, 240, 18)
            draw_bar(surface, hp_rect, self.phobia.hp / self.phobia.max_hp, hp_color(self.phobia.hp / self.phobia.max_hp),
                     label=f"{self.phobia.hp}/{self.phobia.max_hp}", font=Fonts.small)

            self._draw_player(surface)
            you_img = Fonts.body.render("You", True, TEXT_MAIN)
            surface.blit(you_img, you_img.get_rect(centerx=PLAYER_ANCHOR[0], top=PLAYER_ANCHOR[1] + 50))

            quote_rect = pygame.Rect(inner.left, inner.top, inner.width, 40)
            draw_text_block(surface, f'"{self.phobia.quote}"', Fonts.small, TEXT_DIM, quote_rect)

            if self.pending_end == "win":
                msg = Fonts.heading.render("The fear dissolves.", True, GOLD)
                surface.blit(msg, msg.get_rect(centerx=MAIN_RECT.centerx, top=inner.bottom - 34))
            elif self.pending_end == "lose":
                msg = Fonts.heading.render("You are overwhelmed...", True, HP_BAD)
                surface.blit(msg, msg.get_rect(centerx=MAIN_RECT.centerx, top=inner.bottom - 34))

        self.app.draw_log(surface)
        mouse = pygame.mouse.get_pos()
        for b in self.buttons:
            b.draw(surface, self.app.mouse_pos)

    def _draw_fear(self, surface, color):
        reveal = self.reveal
        pulse = math.sin(self.pulse * 4) * 5
        radius = int(20 + 35 * reveal + pulse)
        aura = pygame.Surface((220, 220), pygame.SRCALPHA)
        for multiplier, alpha in ((2.4, 18), (1.8, 30), (1.3, 46)):
            aura_radius = int(radius * multiplier)
            pygame.draw.circle(aura, (*color, alpha), (110, 110), aura_radius)
        surface.blit(aura, aura.get_rect(center=ENEMY_ANCHOR))

        points = []
        for index in range(12):
            angle = math.tau * index / 12 - math.pi / 2
            jagged = radius + (12 if index % 2 else -5) * reveal
            points.append((ENEMY_ANCHOR[0] + math.cos(angle) * jagged,
                           ENEMY_ANCHOR[1] + math.sin(angle) * jagged))
        pygame.draw.polygon(surface, color, points)
        pygame.draw.polygon(surface, (12, 9, 18), points, width=3)

        eye_offset = int(radius * 0.33)
        eye_y = ENEMY_ANCHOR[1] - int(radius * 0.1)
        eye_color = (255, 238, 205)
        for direction in (-1, 1):
            pygame.draw.circle(surface, eye_color, (ENEMY_ANCHOR[0] + direction * eye_offset, eye_y), max(2, int(4 * reveal)))

        for index in range(16):
            angle = self.pulse * (0.7 + index % 3 * 0.12) + index * math.tau / 16
            distance = radius * (1.4 + (index % 4) * 0.16)
            x = int(ENEMY_ANCHOR[0] + math.cos(angle) * distance)
            y = int(ENEMY_ANCHOR[1] + math.sin(angle) * distance * 0.65)
            pygame.draw.circle(surface, (*color, 150), (x, y), 1 + index % 3)

    def _draw_player(self, surface):
        aura = pygame.Surface((160, 160), pygame.SRCALPHA)
        aura_radius = int(48 + math.sin(self.pulse * 3) * 3)
        pygame.draw.circle(aura, (*INSIGHT_COLOR, 18), (80, 80), aura_radius + 18)
        pygame.draw.circle(aura, (*INSIGHT_COLOR, 42), (80, 80), aura_radius)
        surface.blit(aura, aura.get_rect(center=PLAYER_ANCHOR))
        x, y = PLAYER_ANCHOR
        robe = [(x, y - 34), (x - 25, y + 36), (x + 25, y + 36)]
        pygame.draw.polygon(surface, (76, 67, 120), robe)
        pygame.draw.polygon(surface, (15, 12, 28), robe, width=2)
        pygame.draw.circle(surface, (224, 194, 166), (x, y - 38), 15)
        pygame.draw.circle(surface, (15, 12, 28), (x, y - 38), 15, width=2)
        pygame.draw.circle(surface, INSIGHT_COLOR, (x, y - 3), 7)

    def _draw_impact(self, surface):
        if self.impact <= 0:
            return
        progress = 1.0 - self.impact
        start = ENEMY_ANCHOR if self.impact_color == HP_BAD else PLAYER_ANCHOR
        end = PLAYER_ANCHOR if self.impact_color == HP_BAD else ENEMY_ANCHOR
        beam = pygame.Surface(MAIN_RECT.size, pygame.SRCALPHA)
        local_start = (start[0] - MAIN_RECT.left, start[1] - MAIN_RECT.top)
        local_end = (end[0] - MAIN_RECT.left, end[1] - MAIN_RECT.top)
        pygame.draw.line(beam, (*self.impact_color, int(150 * self.impact)), local_start, local_end, width=max(2, int(10 * self.impact)))
        flash_radius = int(16 + progress * 72)
        pygame.draw.circle(beam, (*self.impact_color, int(120 * self.impact)), local_end, flash_radius)
        surface.blit(beam, MAIN_RECT.topleft)

    def _draw_item_menu(self, surface, inner):
        title = Fonts.heading.render("Use which item?", True, GOLD)
        surface.blit(title, (inner.left, inner.top))
        items = [i for i in self.player.inventory if getattr(i, "heal", 0) or getattr(i, "insight_restore", 0)]
        rects = layout_row(max(len(items), 1), pygame.Rect(inner.left, inner.top + 60, inner.width, 60))
        item_buttons = []
        for item, rect in zip(items, rects):
            btn = Button(rect, item.name, (lambda it=item: self._use_item(it)), subtitle=item.description[:28])
            item_buttons.append(btn)
        for b in item_buttons:
            b.draw(surface, self.app.mouse_pos)
        self._item_buttons = item_buttons

    def handle_event(self, event):
        if self.show_items and not self.pending_end:
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                for b in getattr(self, "_item_buttons", []):
                    if b.handle_click(event.pos):
                        return
                self.show_items = False
                return
        super().handle_event(event)


class GameOverScene(Scene):
    def __init__(self, app):
        super().__init__(app)
        rect = pygame.Rect(0, 0, 300, 60)
        rect.center = (SCREEN_W // 2, 460)
        self.buttons = [Button(rect, "Try Again", app.start_new_game, hotkey=pygame.K_RETURN)]

    def draw(self, surface):
        veil = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
        veil.fill((*HP_BAD, 32))
        surface.blit(veil, (0, 0))
        title = Fonts.title.render("YOUR FEARS OVERWHELM YOU", True, HP_BAD)
        surface.blit(title, title.get_rect(centerx=SCREEN_W // 2, top=220))
        sub = Fonts.body.render("THE END", True, TEXT_DIM)
        surface.blit(sub, sub.get_rect(centerx=SCREEN_W // 2, top=300))
        for b in self.buttons:
            b.draw(surface, self.app.mouse_pos)


class WinScene(Scene):
    def __init__(self, app):
        super().__init__(app)
        rect = pygame.Rect(0, 0, 300, 60)
        rect.center = (SCREEN_W // 2, 480)
        self.buttons = [Button(rect, "Play Again", app.start_new_game, hotkey=pygame.K_RETURN)]

    def draw(self, surface):
        dawn = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
        pygame.draw.circle(dawn, (255, 222, 146, 36), (SCREEN_W // 2, 285), 260)
        pygame.draw.circle(dawn, (255, 244, 207, 34), (SCREEN_W // 2, 285), 150)
        surface.blit(dawn, (0, 0))
        title = Fonts.title.render("THE SIN OF FEY DISSOLVES", True, GOLD)
        surface.blit(title, title.get_rect(centerx=SCREEN_W // 2, top=200))
        blurb_rect = pygame.Rect(SCREEN_W // 2 - 380, 270, 760, 140)
        draw_text_block(
            surface,
            "You have named every fear across all three books: Esoteric "
            "Psychology, Phobia, and The Green Apple. The garden is only a "
            "garden now, and the apple is only an apple.",
            Fonts.body, TEXT_MAIN, blurb_rect,
        )
        for b in self.buttons:
            b.draw(surface, self.app.mouse_pos)


async def main():
    await App().run()
    return 0
