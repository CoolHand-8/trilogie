"""Visual theme: colors, fonts and layout constants."""

from __future__ import annotations

import math

import pygame

from engine.elements import Element

SCREEN_W, SCREEN_H = 1100, 720

BG_TOP = (14, 12, 24)
BG_BOTTOM = (32, 20, 46)
PANEL_BG = (24, 20, 36)
PANEL_BORDER = (94, 74, 130)
TEXT_MAIN = (238, 232, 245)
TEXT_DIM = (162, 150, 178)
TEXT_ACCENT = (222, 178, 250)
GOLD = (224, 190, 110)
HP_GOOD = (120, 200, 120)
HP_MID = (222, 190, 90)
HP_BAD = (210, 90, 90)
INSIGHT_COLOR = (120, 180, 235)

ELEMENT_COLORS = {
    Element.AIR: (196, 224, 232),
    Element.WATER: (94, 150, 214),
    Element.EARTH: (140, 112, 74),
    Element.FIRE: (214, 96, 62),
    Element.SPIRIT: (176, 118, 220),
}


class Fonts:
    title: pygame.font.Font
    heading: pygame.font.Font
    body: pygame.font.Font
    small: pygame.font.Font
    button: pygame.font.Font

    @classmethod
    def load(cls):
        pygame.font.init()
        serif = pygame.font.match_font("georgia,garamond,times new roman,serif")
        mono = pygame.font.match_font("consolas,dejavusansmono,monospace")
        cls.title = pygame.font.Font(serif, 46)
        cls.heading = pygame.font.Font(serif, 28)
        cls.body = pygame.font.Font(serif, 20)
        cls.small = pygame.font.Font(mono, 16)
        cls.button = pygame.font.Font(serif, 20)
        return cls


def vertical_gradient(surface: pygame.Surface, top, bottom) -> None:
    h = surface.get_height()
    w = surface.get_width()
    for y in range(h):
        t = y / max(1, h - 1)
        color = tuple(int(top[i] + (bottom[i] - top[i]) * t) for i in range(3))
        pygame.draw.line(surface, color, (0, y), (w, y))


def draw_atmosphere(surface: pygame.Surface, time: float, intensity: float = 0.0) -> None:
    """Paint a living, vignetted backdrop behind all game scenes."""
    vertical_gradient(surface, BG_TOP, BG_BOTTOM)
    width, height = surface.get_size()
    haze = pygame.Surface((width, height), pygame.SRCALPHA)

    for index, (x_factor, y_factor, radius, color) in enumerate((
        (0.17, 0.22, 260, (91, 61, 129)),
        (0.83, 0.38, 310, (52, 89, 133)),
        (0.48, 0.88, 360, (117, 64, 92)),
    )):
        drift_x = math.sin(time * (0.18 + index * 0.04) + index) * 55
        drift_y = math.cos(time * (0.15 + index * 0.03) + index) * 35
        center = (int(width * x_factor + drift_x), int(height * y_factor + drift_y))
        for ring in range(4, 0, -1):
            alpha = int((7 + intensity * 7) * ring)
            pygame.draw.circle(haze, (*color, alpha), center, radius * ring // 4)

    for index in range(46):
        x = int((index * 83 + math.sin(time * 0.28 + index) * 42) % width)
        y = int((index * 137 + time * (9 + index % 5)) % height)
        alpha = 16 + int(14 * (1 + math.sin(time * 1.4 + index)))
        pygame.draw.circle(haze, (232, 221, 255, alpha), (x, y), 1 + index % 2)

    surface.blit(haze, (0, 0))
    vignette = pygame.Surface((width, height), pygame.SRCALPHA)
    for inset, alpha in ((0, 72), (18, 36), (42, 18)):
        pygame.draw.rect(vignette, (5, 4, 11, alpha), (inset, inset, width - inset * 2, height - inset * 2), width=18)
    surface.blit(vignette, (0, 0))
