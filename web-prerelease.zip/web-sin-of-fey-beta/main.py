#!/usr/bin/env python3
"""Web (browser) entry point for The Sin of Fey, built for pygbag."""

import asyncio

import pygame

pygame.init()

from gui.app import main as _main

if __name__ == "__main__":
    asyncio.run(_main())