#!/usr/bin/env bash
# Launch the pygame (graphical) game inside its .venv, creating/installing it on first run.
set -e
cd "$(dirname "$0")"

if [ ! -d ".venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv .venv
    .venv/bin/pip install --quiet --upgrade pip
    .venv/bin/pip install --quiet -e .
fi

if ! .venv/bin/python -c "import pygame" >/dev/null 2>&1; then
    echo "Installing pygame-ce (graphical dependency)..."
    .venv/bin/pip install --quiet pygame-ce
fi

exec .venv/bin/python gui_main.py
