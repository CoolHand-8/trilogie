#!/usr/bin/env bash
# Launch the text (CLI) game inside its .venv, creating/installing it on first run.
set -e
cd "$(dirname "$0")"

if [ ! -d ".venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv .venv
    .venv/bin/pip install --quiet --upgrade pip
    .venv/bin/pip install --quiet -e .
fi

exec .venv/bin/python main.py
