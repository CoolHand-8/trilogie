"""Engine package for The Green Apple: The Sin of Fey (text adventure)."""
