"""Chakra system used as the player's resource for special "Reflect" attacks.

Drawn from the "Chakras" list and "Faculty and the Throat Chakra" chapter of
Esoteric Psychology.
"""

from dataclasses import dataclass, field
from enum import Enum


class Chakra(Enum):
    ROOT = "Root"
    SACRAL = "Sacral"
    SOLAR_PLEXUS = "Solar Plexus"
    HEART = "Heart"
    THROAT = "Throat"
    THIRD_EYE = "Third Eye"
    CROWN = "Crown"

    def __str__(self) -> str:
        return self.value


CHAKRA_ORDER = [
    Chakra.ROOT,
    Chakra.SACRAL,
    Chakra.SOLAR_PLEXUS,
    Chakra.HEART,
    Chakra.THROAT,
    Chakra.THIRD_EYE,
    Chakra.CROWN,
]


@dataclass
class ChakraSystem:
    """Tracks which chakras a player has "opened" and how much Insight
    (chakra energy) is available for special attacks."""

    insight: int = 20
    max_insight: int = 20
    opened: set = field(default_factory=lambda: {Chakra.ROOT})

    def open_chakra(self, chakra: Chakra) -> bool:
        if chakra in self.opened:
            return False
        self.opened.add(chakra)
        self.max_insight += 5
        self.insight = self.max_insight
        return True

    def spend(self, amount: int) -> bool:
        if self.insight < amount:
            return False
        self.insight -= amount
        return True

    def restore(self, amount: int) -> None:
        self.insight = min(self.max_insight, self.insight + amount)

    def progress_str(self) -> str:
        marks = [
            f"[{c.value}]" if c in self.opened else f" {c.value} "
            for c in CHAKRA_ORDER
        ]
        return " - ".join(marks)
