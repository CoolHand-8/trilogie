"""Items and artifacts, named after recurring symbols in the trilogy
(the Pendulum, Mercury, the Diamond of the Mind, the Green/Red Apple...)."""

from dataclasses import dataclass
from typing import Optional

from .elements import Element


@dataclass
class Item:
    name: str
    description: str

    def __str__(self) -> str:
        return self.name


@dataclass
class KeyItem(Item):
    """An item required to unlock a specific locked room."""


@dataclass
class Artifact(Item):
    """An item that grants (or empowers) an elemental "Reflect" attack and
    can also heal or restore insight when used."""

    element: Optional[Element] = None
    attack_bonus: int = 0
    heal: int = 0
    insight_restore: int = 0

    def use_message(self) -> str:
        return f"You focus on the {self.name}. {self.description}"
