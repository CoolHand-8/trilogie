"""Elemental system: Air, Water, Earth, Fire and Spirit (from "Third Person
Dialogue: Air, Water, Earth and Fire" in Esoteric Psychology)."""

from enum import Enum


class Element(Enum):
    AIR = "Air"
    WATER = "Water"
    EARTH = "Earth"
    FIRE = "Fire"
    SPIRIT = "Spirit"

    def __str__(self) -> str:
        return self.value


# Classic elemental circle, plus Spirit which is strong against all and
# weak to none but itself (represents the "esoteric"/beyond-elemental fears).
_STRONG_AGAINST = {
    Element.AIR: Element.EARTH,
    Element.EARTH: Element.FIRE,
    Element.FIRE: Element.AIR,
    Element.WATER: Element.FIRE,
    Element.SPIRIT: Element.SPIRIT,
}


def effectiveness(attacker: Element, defender: Element) -> float:
    """Return a damage multiplier for attacker's element vs defender's element."""
    if _STRONG_AGAINST.get(attacker) == defender and attacker is not defender:
        return 1.5
    if _STRONG_AGAINST.get(defender) == attacker:
        return 0.5
    return 1.0
