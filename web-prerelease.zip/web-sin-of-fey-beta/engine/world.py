"""The world: Rooms grouped into Acts (one per book of the trilogy)."""

from dataclasses import dataclass, field
from typing import List, Optional

from .entities import Phobia
from .items import Item, KeyItem


@dataclass
class Room:
    key: str
    title: str
    flavor: str
    reflection: str = ""
    phobia: Optional[Phobia] = None
    item: Optional[Item] = None
    requires_key: Optional[str] = None
    cleared: bool = False
    visited: bool = False
    grounded: bool = False

    def is_locked(self, player) -> bool:
        if not self.requires_key:
            return False
        return not player.has_item(self.requires_key)


@dataclass
class Act:
    title: str
    book: str
    rooms: List[Room] = field(default_factory=list)
    position: int = 0

    def current(self) -> Room:
        return self.rooms[self.position]

    def has_next(self) -> bool:
        return self.position < len(self.rooms) - 1

    def advance(self) -> Optional[Room]:
        if self.has_next():
            self.position += 1
            return self.current()
        return None

    def is_complete(self) -> bool:
        return all(r.cleared for r in self.rooms)


@dataclass
class World:
    acts: List[Act]
    act_index: int = 0

    def current_act(self) -> Act:
        return self.acts[self.act_index]

    def next_act(self) -> Optional[Act]:
        if self.act_index < len(self.acts) - 1:
            self.act_index += 1
            return self.current_act()
        return None

    def is_final_act(self) -> bool:
        return self.act_index == len(self.acts) - 1
