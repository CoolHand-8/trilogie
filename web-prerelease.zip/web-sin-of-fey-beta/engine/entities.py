"""Characters: the Player and the Phobias (enemies) they confront."""

from dataclasses import dataclass, field
from typing import List, Optional

from .chakras import Chakra, ChakraSystem
from .elements import Element, effectiveness
from .items import Artifact, Item


@dataclass
class Character:
    name: str
    max_hp: int
    hp: int = field(init=False)
    element: Element = Element.SPIRIT

    def __post_init__(self):
        self.hp = self.max_hp

    @property
    def alive(self) -> bool:
        return self.hp > 0

    def take_damage(self, amount: int) -> int:
        amount = max(0, amount)
        self.hp = max(0, self.hp - amount)
        return amount


class Phobia(Character):
    """A named fear drawn from the trilogy's chapter titles, e.g. Insomnia,
    Sociopathy, Grimwitch the Warlock, the Diamond of the Mind."""

    def __init__(
        self,
        name: str,
        max_hp: int,
        element: Element,
        attack: int,
        quote: str,
        reward: Optional[Item] = None,
    ):
        super().__init__(name=name, max_hp=max_hp, element=element)
        self.attack = attack
        self.quote = quote
        self.reward = reward

    def strike(self) -> int:
        return self.attack


class Player(Character):
    def __init__(self, name: str):
        super().__init__(name=name, max_hp=40, element=Element.SPIRIT)
        self.chakras = ChakraSystem()
        self.inventory: List[Item] = []
        self.base_attack = 5
        self.artifacts: List[Artifact] = []

    def add_item(self, item: Item) -> None:
        self.inventory.append(item)
        if isinstance(item, Artifact) and item.element is not None:
            self.artifacts.append(item)

    def has_item(self, name: str) -> bool:
        return any(i.name.lower() == name.lower() for i in self.inventory)

    def confront(self) -> int:
        """A plain physical/verbal attack, no chakra cost."""
        return self.base_attack

    def best_reflect_element(self, defender_element: Element) -> Optional[Artifact]:
        """Pick the strongest artifact (by effectiveness) against a target."""
        if not self.artifacts:
            return None
        return max(
            self.artifacts,
            key=lambda a: effectiveness(a.element, defender_element) + a.attack_bonus / 100,
        )

    def reflect(self, artifact: Artifact, defender_element: Element) -> int:
        """A chakra-powered elemental attack using an artifact."""
        base = self.base_attack + 6 + artifact.attack_bonus
        mult = effectiveness(artifact.element, defender_element)
        return round(base * mult)

    def rest(self) -> None:
        self.hp = min(self.max_hp, self.hp + 10)
        self.chakras.restore(8)
