#!/usr/bin/env python3
"""Pygame entry point for The Sin of Fey.

Run with: python3 gui_main.py
"""

import sys

from gui.app import main

if __name__ == "__main__":
    sys.exit(main())
