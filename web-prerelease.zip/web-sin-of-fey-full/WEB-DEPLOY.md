# Deploying this web build

The playable browser build lives in `build/web/`:

- `index.html` — the page to open/host
- `web-sin-of-fey-full.apk` — the packaged Python/game code (a zip, loaded by index.html)
- `favicon.png`

## Host it
Upload the **contents of `build/web/`** to any static web host (itch.io "HTML5" upload,
GitHub Pages, Netlify, S3, etc.) and open `index.html`. No server-side code is needed;
it must be served over http(s), not opened as a local `file://` path.

## Rebuild after editing the source
The source (`main.py`, `engine/`, `data/`, `gui/`) is a browser-adapted copy of the
most feature-complete pygame game (async main loop for pygbag, windowed instead of
fullscreen). To rebuild after changes:

```
python -m pip install pygbag
python -m pygbag --build --archive .
```

This regenerates `build/web/`.
