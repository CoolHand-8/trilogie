#!/usr/bin/env python3
"""The Sin of Fey — a text adventure built on the "trilogie" books:
Esoteric Psychology, Phobia, and The Green Apple.

Run with: python3 main.py
"""

import sys

from data.story import build_world
from engine.chakras import CHAKRA_ORDER
from engine.combat import Combat, CombatResult
from engine.entities import Player
from engine.world import World


class ConsoleIO:
    def say(self, text: str = "") -> None:
        print(text)

    def ask(self, prompt: str) -> str:
        try:
            return input(prompt)
        except EOFError:
            return "quit"


class Game:
    def __init__(self):
        self.io = ConsoleIO()
        self.world: World = build_world()
        self.player: Player = Player(name="Jesse")
        self.running = True

    def intro(self) -> None:
        self.io.say("=" * 60)
        self.io.say("        THE SIN OF FEY — a journey through the trilogy")
        self.io.say("=" * 60)
        self.io.say(
            "\nYou carry three books worth of fear: Esoteric Psychology, "
            "Phobia, and The Green Apple.\nEach room is a chapter. Each "
            "chapter holds a fear given a name. Naming it is how you win.\n"
        )
        self.io.say("Combat commands: [c]onfront, [r]eflect, [i]tem, [f]lee")
        self.io.say("Exploration commands: look, inventory, chakras, c (confront/advance), quit\n")

    def run(self) -> None:
        self.intro()
        while self.running and self.player.alive:
            act = self.world.current_act()
            self.io.say(f"\n--- {act.title}: {act.book} ---")
            self.explore_act(act)

            if not self.running or not self.player.alive:
                break

            if not act.is_complete():
                # Player fled the act without finishing every room.
                continue

            if self.world.is_final_act():
                self.io.say(
                    "\nYou have named every fear across all three books. "
                    "The Sin of Fey dissolves into ordinary sunlight.\n"
                    "THE END."
                )
                self.running = False
            else:
                self.io.say(f"\nYou close the book on {act.book}. Turning the page...\n")
                self.world.next_act()

        if not self.player.alive:
            self.io.say("\nYour fears have overwhelmed you. THE END.")

    def explore_act(self, act) -> None:
        while self.running and not act.is_complete() and self.player.alive:
            room = act.current()
            self.enter_room(act, room)
            if not self.running or not self.player.alive:
                return
            if room.cleared or room.phobia is None:
                if not act.has_next():
                    break
                act.advance()

    def enter_room(self, act, room) -> None:
        io = self.io
        if room.is_locked(self.player):
            io.say(f"\n[{room.title}] is locked. You need: {room.requires_key}.")
            if act.has_next():
                act.advance()
            return

        if not room.visited:
            room.visited = True
            io.say(f"\n== {room.title} ==")
            io.say(room.flavor)

        while self.running:
            if room.cleared or room.phobia is None:
                if room.item and not room.cleared:
                    self.take_item(room)
                room.cleared = True
                return

            cmd = io.ask("\n(explore) > ").strip().lower()
            if cmd in ("look",):
                io.say(room.flavor)
                if room.phobia and room.phobia.alive:
                    io.say(f"A fear lingers here: {room.phobia.name}.")
            elif cmd in ("inventory", "inv", "i"):
                self.show_inventory()
            elif cmd in ("chakras",):
                io.say(self.player.chakras.progress_str())
                io.say(f"Insight: {self.player.chakras.insight}/{self.player.chakras.max_insight}")
            elif cmd in ("quit", "exit"):
                self.running = False
                return
            elif cmd in ("c", "confront", "fight", "advance", "go", ""):
                result = Combat(self.player, room.phobia, io).run()
                if result == CombatResult.WIN:
                    room.cleared = True
                    if room.item:
                        self.take_item(room)
                    return
                elif result == CombatResult.LOSE:
                    return
                elif result == CombatResult.FLED:
                    self.player.rest()
                    io.say("You rest and gather yourself. (HP and Insight partially restored.)")
            else:
                io.say("Unknown command. Try: look, inventory, chakras, confront, quit")

    def take_item(self, room) -> None:
        item = room.item
        room.item = None
        self.player.add_item(item)
        self.io.say(f"You take the {item.name}. {item.description}")
        for chakra in CHAKRA_ORDER:
            if chakra not in self.player.chakras.opened and len(self.player.artifacts) >= 1:
                if self.player.chakras.open_chakra(chakra):
                    self.io.say(f"A new chakra opens within you: {chakra}.")
                break

    def show_inventory(self) -> None:
        if not self.player.inventory:
            self.io.say("Your pockets are empty.")
            return
        for item in self.player.inventory:
            self.io.say(f" - {item.name}: {item.description}")


def main() -> int:
    game = Game()
    game.run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
