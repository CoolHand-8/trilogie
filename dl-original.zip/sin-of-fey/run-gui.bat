@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if not errorlevel 1 (
    set PYTHON_CMD=py -3
) else if where python >nul 2>nul (
    set PYTHON_CMD=python
) else (
    echo Python 3 is required but was not found on PATH.
    exit /b 1
)

if not exist ".venv" (
    echo Creating virtual environment...
    %PYTHON_CMD% -m venv .venv
    .venv\Scripts\python -m pip install --upgrade pip
    .venv\Scripts\python -m pip install -e .
)

.venv\Scripts\python -c "import pygame" >nul 2>&1
if errorlevel 1 (
    echo Installing pygame-ce (graphical dependency)...
    .venv\Scripts\python -m pip install pygame-ce
)

.venv\Scripts\python gui_main.py
