"""Visual theme: colors, fonts and layout constants."""

import pygame

from engine.elements import Element

SCREEN_W, SCREEN_H = 1100, 720

BG_TOP = (14, 12, 24)
BG_BOTTOM = (32, 20, 46)
PANEL_BG = (24, 20, 36)
PANEL_BORDER = (94, 74, 130)
TEXT_MAIN = (238, 232, 245)
TEXT_DIM = (162, 150, 178)
TEXT_ACCENT = (222, 178, 250)
GOLD = (224, 190, 110)
HP_GOOD = (120, 200, 120)
HP_MID = (222, 190, 90)
HP_BAD = (210, 90, 90)
INSIGHT_COLOR = (120, 180, 235)

ELEMENT_COLORS = {
    Element.AIR: (196, 224, 232),
    Element.WATER: (94, 150, 214),
    Element.EARTH: (140, 112, 74),
    Element.FIRE: (214, 96, 62),
    Element.SPIRIT: (176, 118, 220),
}


class Fonts:
    title: pygame.font.Font
    heading: pygame.font.Font
    body: pygame.font.Font
    small: pygame.font.Font
    button: pygame.font.Font

    @classmethod
    def load(cls):
        pygame.font.init()
        serif = pygame.font.match_font("georgia,garamond,times new roman,serif")
        mono = pygame.font.match_font("consolas,dejavusansmono,monospace")
        cls.title = pygame.font.Font(serif, 46)
        cls.heading = pygame.font.Font(serif, 28)
        cls.body = pygame.font.Font(serif, 20)
        cls.small = pygame.font.Font(mono, 16)
        cls.button = pygame.font.Font(serif, 20)
        return cls


def vertical_gradient(surface: pygame.Surface, top, bottom) -> None:
    h = surface.get_height()
    w = surface.get_width()
    for y in range(h):
        t = y / max(1, h - 1)
        color = tuple(int(top[i] + (bottom[i] - top[i]) * t) for i in range(3))
        pygame.draw.line(surface, color, (0, y), (w, y))
